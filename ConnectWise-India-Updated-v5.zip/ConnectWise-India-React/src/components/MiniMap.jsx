import {useEffect,useRef} from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {useApp} from '../context/AppContext';

export default function MiniMap(){
  const ref=useRef(null), mapRef=useRef(null), markerRef=useRef(null); const {location}=useApp();
  useEffect(()=>{
    if(!ref.current || mapRef.current) return;
    const map=L.map(ref.current,{zoomControl:false,attributionControl:true,scrollWheelZoom:false,dragging:false,doubleClickZoom:false,touchZoom:false,boxZoom:false,keyboard:false,preferCanvas:true});
    mapRef.current=map;
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors',maxZoom:19,tileSize:256,detectRetina:true}).addTo(map);
    markerRef.current=L.circleMarker([location.lat,location.lng],{radius:8,weight:3,fillOpacity:.95}).addTo(map);
    markerRef.current.bindPopup(`<b>${location.name}</b><br/>Selected area`);
    map.setView([location.lat,location.lng],12,{animate:false});
    const resize=()=>map.invalidateSize({pan:false}); requestAnimationFrame(resize); const timer=setTimeout(resize,250);
    return()=>{clearTimeout(timer);map.remove();mapRef.current=null;markerRef.current=null};
  },[]);
  useEffect(()=>{const map=mapRef.current,marker=markerRef.current;if(!map||!marker)return;const point=[location.lat,location.lng];marker.setLatLng(point).setPopupContent(`<b>${location.name}</b><br/>Selected area`);map.setView(point,12,{animate:false});setTimeout(()=>map.invalidateSize({pan:false}),50)},[location]);
  return <div className="mapPreview miniLeafletMap"><div ref={ref} className="miniLeafletInner" aria-label={`Map preview for ${location.name}`}/></div>;
}
