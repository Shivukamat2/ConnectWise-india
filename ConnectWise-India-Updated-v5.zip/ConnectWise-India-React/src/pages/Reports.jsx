import {useMemo} from 'react';
import {useApp} from '../context/AppContext';
import {Button,Metric,SectionTitle,Pill} from '../components/UI';
import {Download,FileText,Router,Activity} from 'lucide-react';

export default function Reports(){
  const {diagnostic,location}=useApp();
  const report=useMemo(()=>diagnostic?{date:new Date().toLocaleString('en-IN'),...diagnostic}:null,[diagnostic]);
  const exportJSON=()=>{
    const data=report||{message:'No diagnostic saved yet'};
    const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));a.download='connectwise-diagnostic.json';a.click();URL.revokeObjectURL(a.href);
  };
  const exportCSV=()=>{
    if(!report)return;
    const rows=Object.entries(report).filter(([,v])=>['string','number'].includes(typeof v)).map(([k,v])=>`${k},${String(v).replaceAll(',',' ')}`).join('\n');
    const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([`Parameter,Value\n${rows}`],{type:'text/csv'}));a.download='connectwise-diagnostic.csv';a.click();URL.revokeObjectURL(a.href);
  };
  return <div className="page">
    <SectionTitle eyebrow="REPORTS" title="Your network and router reports" text="Reports are generated from the current simulated diagnostic session. Diagnostic results can describe either a connection or a router environment."/>
    <div className="reportHeader"><div><b>{location.name}</b><span> · Demo / estimated telemetry</span></div><div className="actionrow"><Button variant="outline" onClick={exportJSON}><Download size={16}/> JSON</Button><Button variant="outline" onClick={exportCSV} disabled={!report}><Download size={16}/> CSV</Button><Button variant="secondary" onClick={()=>window.print()}><FileText size={16}/> Print</Button></div></div>
    {report?<div className="reportCard">
      <div><Pill>{report.type==='router'?'Router Diagnostic':'Network Diagnostic'}</Pill><h3>{report.type==='router'?report.router:'Connection performance'}</h3><p>{location.name} · {report.date}</p></div>
      <Metric label="Health" value={`${report.type==='router'?report.routerHealth:report.health}/100`} sub={report.type==='router'?report.status:'Simulated'} icon={Activity}/>
      <Metric label="Download" value={`${report.download} Mbps`} sub="Estimated"/>
      <Metric label={report.type==='router'?'Wi-Fi signal':'Ping'} value={report.type==='router'?`${report.signal} dBm`:`${report.ping} ms`} sub="Estimated" icon={report.type==='router'?Router:Activity}/>
    </div>:<div className="empty"><FileText size={34}/><h3>No reports yet</h3><p>Run a network or router diagnostic and your report will appear here.</p><Button to="/diagnostic">Run diagnostic</Button></div>}
  </div>
}
