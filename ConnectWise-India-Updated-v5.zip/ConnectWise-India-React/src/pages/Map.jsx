import {useEffect,useRef,useState} from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {SectionTitle,ChoiceCard,Pill,Button} from '../components/UI';
import {providers,nearbyWifi} from '../data/data';
import {useApp} from '../context/AppContext';

export default function MapPage(){
  const ref=useRef(null), mapRef=useRef(null), [provider,setProvider]=useState('all');
  const {location}=useApp();

  useEffect(()=>{
    if(!ref.current)return;
    const map=L.map(ref.current).setView([location.lat,location.lng],11);
    mapRef.current=map;
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors'}).addTo(map);
    const selected=L.circleMarker([location.lat,location.lng],{radius:9,weight:3,fillOpacity:.95}).addTo(map).bindPopup(`<b>${location.name}</b><br/>Selected location`).openPopup();
    map.on('click',e=>selected.setLatLng(e.latlng).setPopupContent(`<b>Selected point</b><br/>${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`).openPopup());
    setTimeout(()=>map.invalidateSize(),50);
    return()=>{map.remove();mapRef.current=null};
  },[location]);

  useEffect(()=>{
    const map=mapRef.current;if(!map)return;
    map.eachLayer(layer=>{if(layer.options?.cwProviderMarker)map.removeLayer(layer)});
    providers.filter(p=>provider==='all'||p.id===provider).forEach((p,i)=>{
      const lat=location.lat+([-.025,.018,.032,-.015][i]||0);
      const lng=location.lng+([-.03,.035,-.012,.02][i]||0);
      L.circleMarker([lat,lng],{radius:7,cwProviderMarker:true,weight:2,fillOpacity:.85}).addTo(map).bindPopup(`<b>${p.name}</b><br/>${p.tech} · Indicative service area`);
    });
  },[provider,location]);

  return <div className="page">
    <SectionTitle eyebrow="BROADBAND & ROUTER AVAILABILITY" title="Explore connectivity at any location" text="Choose a point, select a provider, or explore indicative area data. Exact installation feasibility requires provider confirmation."/>
    <div className="mapControls"><label>Provider<select value={provider} onChange={e=>setProvider(e.target.value)}><option value="all">All providers</option>{providers.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label><Button variant="outline" onClick={()=>mapRef.current?.setView([location.lat,location.lng],13)}>Center on selected area</Button></div>
    <div className="mapLayout"><div className="mapBox" ref={ref}/><aside className="mapSide"><div className="card"><Pill>Selected location</Pill><h3>{location.name}</h3><p className="muted">Indicative options in this area</p>{providers.filter(p=>provider==='all'||p.id===provider).map(p=><div className="providerLine" key={p.id}><span><b>{p.name}</b><small>{p.tech} · {p.plans.length} demo plans</small></span><span>Indicative*</span></div>)}<small>*Availability shown here is simulated/indicative.</small></div><div className="card"><Pill>People’s Choice</Pill><h3>Nearby Wi-Fi environment</h3><p className="muted">Anonymous SSID examples for the demo. Real Wi-Fi scanning depends on OS/browser permissions.</p>{nearbyWifi.map(x=><div className="ssid" key={x}>{x}</div>)}</div></aside></div>
    <div className="grid g2 section compact"><ChoiceCard type="people" title="What names you may see around you">Common Wi-Fi names can be a useful local signal, but an SSID does not prove service availability or identify its owner.</ChoiceCard><ChoiceCard type="connect" title="ConnectWise Choice">Open a provider, plan or router and use the comparison flow to understand one concrete data-driven option for your needs.</ChoiceCard></div>
  </div>
}
