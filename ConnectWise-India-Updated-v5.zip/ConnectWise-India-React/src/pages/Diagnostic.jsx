import {useState} from 'react';
import {useNavigate} from 'react-router-dom';
import {runDiagnostic,runRouterDiagnostic} from '../services/diagnostic';
import {useApp} from '../context/AppContext';
import {Button,SectionTitle} from '../components/UI';
import {Activity,Signal,Router} from 'lucide-react';

export default function Diagnostic(){
  const {location,setDiagnostic}=useApp(); const nav=useNavigate(); const [step,setStep]=useState(1); const [type,setType]=useState('network');
  const [settings,setSettings]=useState({plan:300,distance:8,walls:1,devices:5,interference:25,band:'5 GHz',router:'Wi-Fi 6 Router',coverage:80,connection:'wifi'});
  const update=(k,v)=>setSettings(s=>({...s,[k]:v}));
  const run=()=>{const result=type==='router'?runRouterDiagnostic(settings):runDiagnostic({...settings,type:settings.connection});setDiagnostic({...result,diagnosticType:type});nav('/diagnostic/results');};
  return <div className="page diagnosticPage">
    <SectionTitle eyebrow="NETWORK & ROUTER DIAGNOSTIC" title="Check your network or your router" text="Two simple diagnostic paths. Results are simulated unless explicitly marked as measured."/>
    <div className="stepper">{['Choose diagnostic','Location','Configure','Results'].map((x,i)=><div className={step>=i+1?'step active':'step'} key={x}><span>{i+1}</span>{x}</div>)}</div>
    {step===1&&<div className="wizard card"><h3>What do you want to diagnose?</h3><div className="optionGrid twoOptions"><button className={type==='network'?'option selected':'option'} onClick={()=>setType('network')}><Activity/>Network / Internet<small>Fiber, broadband or 4G/5G connection</small></button><button className={type==='router'?'option selected':'option'} onClick={()=>setType('router')}><Router/>Router / Wi-Fi<small>Router health, coverage and local Wi-Fi</small></button></div><Button onClick={()=>setStep(2)}>Continue</Button></div>}
    {step===2&&<div className="wizard card"><h3>Where are you?</h3><p>Your selected area: <b>{location.name}</b></p><p className="muted">Location is simulation context and does not represent a live measurement from your device.</p><div className="actionrow"><Button variant="outline" onClick={()=>setStep(1)}>Back</Button><Button onClick={()=>setStep(3)}>Continue</Button></div></div>}
    {step===3&&<div className="wizard card"><h3>{type==='router'?'Configure your router environment':'Configure your connection'}</h3><div className="formgrid">
      {type==='network'&&<label>Connection type<select value={settings.connection} onChange={e=>update('connection',e.target.value)}><option value="wifi">Fiber / Wi-Fi</option><option value="cellular">4G / 5G</option></select></label>}
      <label>{type==='router'?'Router baseline (Mbps)':'Internet plan (Mbps)'}<input type="number" min="10" value={settings.plan} onChange={e=>update('plan',Math.max(10,+e.target.value||10))}/></label>
      <label>Distance from router (m)<input type="number" min="0" value={settings.distance} onChange={e=>update('distance',Math.max(0,+e.target.value||0))}/></label><label>Concrete walls<input type="number" min="0" value={settings.walls} onChange={e=>update('walls',Math.max(0,+e.target.value||0))}/></label><label>Connected devices<input type="number" min="0" value={settings.devices} onChange={e=>update('devices',Math.max(0,+e.target.value||0))}/></label><label>Interference %<input type="number" min="0" max="100" value={settings.interference} onChange={e=>update('interference',Math.max(0,Math.min(100,+e.target.value||0)))}/></label><label>Frequency band<select value={settings.band} onChange={e=>update('band',e.target.value)}><option>5 GHz</option><option>2.4 GHz</option><option>6 GHz</option></select></label>
      {type==='router'&&<><label>Router type<select value={settings.router} onChange={e=>update('router',e.target.value)}><option>Wi-Fi 6 Router</option><option>Wi-Fi 6E Router</option><option>ISP Gateway</option><option>5G CPE</option><option>Fiber ONT + Wi-Fi Router</option></select></label><label>Coverage baseline %<input type="number" min="20" max="100" value={settings.coverage} onChange={e=>update('coverage',Math.max(20,Math.min(100,+e.target.value||20)))}/></label></>}
    </div><div className="actionrow"><Button variant="outline" onClick={()=>setStep(2)}>Back</Button><Button onClick={run}><Activity size={17}/> Run diagnostic</Button></div></div>}
  </div>;
}
