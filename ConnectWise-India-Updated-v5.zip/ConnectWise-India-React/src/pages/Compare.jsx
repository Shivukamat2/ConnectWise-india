import {useMemo, useState} from 'react';
import {useApp} from '../context/AppContext';
import {Button, Pill, SectionTitle} from '../components/UI';
import {ArrowLeftRight, Share2, Download, Router, Wifi, Signal} from 'lucide-react';
import {providers, routers, mobiles} from '../data/data';

const providerItems = providers.filter(p => p.kind === 'Broadband');

const money = value => value === undefined || value === null ? '—' : `₹${value}/month`;
const text = value => value === undefined || value === null || value === '' ? '—' : value;
const planLabel = plan => plan?.name || `${plan?.speed || ''} Mbps plan`;

function ProviderSelector({value, onChange, exclude}) {
  return <select value={value || ''} onChange={e => onChange(e.target.value)}>
    {providerItems.map(provider => <option key={provider.id} value={provider.id} disabled={provider.id === exclude}>
      {provider.name}
    </option>)}
  </select>;
}

export default function Compare(){
  const {setComparison} = useApp();
  const [category, setCategory] = useState('broadband');
  const [networkA, setNetworkA] = useState('jio5g');
  const [networkB, setNetworkB] = useState('airtel5g');
  const [routerA, setRouterA] = useState(routers[0]?.id);
  const [routerB, setRouterB] = useState(routers[1]?.id);
  const [providerA, setProviderA] = useState('airtel');
  const [providerB, setProviderB] = useState('jio');
  const [planA, setPlanA] = useState('');
  const [planB, setPlanB] = useState('');

  const A = useMemo(() => {
    if(category === 'networks') return mobiles.find(x => x.id === networkA) || mobiles[0];
    if(category === 'routers') return routers.find(x => x.id === routerA) || routers[0];
    return providerItems.find(x => x.id === providerA) || providerItems[0];
  }, [category, networkA, routerA, providerA]);

  const B = useMemo(() => {
    if(category === 'networks') return mobiles.find(x => x.id === networkB) || mobiles[1] || mobiles[0];
    if(category === 'routers') return routers.find(x => x.id === routerB) || routers[1] || routers[0];
    return providerItems.find(x => x.id === providerB) || providerItems[1] || providerItems[0];
  }, [category, networkB, routerB, providerB]);

  const selectedPlanA = category === 'broadband' ? A?.plans?.find(p => p.id === planA) : null;
  const selectedPlanB = category === 'broadband' ? B?.plans?.find(p => p.id === planB) : null;

  const switchCategory = next => {
    setCategory(next);
    setComparison([]);
  };

  const changeProvider = (side, id) => {
    if(side === 'A') { setProviderA(id); setPlanA(''); }
    else { setProviderB(id); setPlanB(''); }
    setComparison([]);
  };

  const rows = useMemo(() => {
    if(category === 'networks') return [
      ['Provider', text(A?.name), text(B?.name)],
      ['Technology', text(A?.tech), text(B?.tech)],
      ['Estimated speed', A?.speed ? `${A.speed} Mbps` : '—', B?.speed ? `${B.speed} Mbps` : '—'],
      ['Latency', A?.latency ? `${A.latency} ms` : '—', B?.latency ? `${B.latency} ms` : '—'],
      ['Signal', text(A?.signal), text(B?.signal)],
      ['RSRP', A?.rsrp ? `${A.rsrp} dBm` : '—', B?.rsrp ? `${B.rsrp} dBm` : '—'],
      ['RSRQ', A?.rsrq ? `${A.rsrq} dB` : '—', B?.rsrq ? `${B.rsrq} dB` : '—'],
      ['SINR', A?.sinr ? `${A.sinr} dB` : '—', B?.sinr ? `${B.sinr} dB` : '—'],
      ['Network load', A?.load !== undefined ? `${A.load}%` : '—', B?.load !== undefined ? `${B.load}%` : '—']
    ];

    if(category === 'routers') return [
      ['Brand', text(A?.brand), text(B?.brand)],
      ['Model', text(A?.model), text(B?.model)],
      ['Wi-Fi generation', text(A?.gen), text(B?.gen)],
      ['Type', text(A?.type), text(B?.type)],
      ['Speed class', text(A?.speed), text(B?.speed)],
      ['Bands', text(A?.bands), text(B?.bands)],
      ['Ethernet', text(A?.ethernet), text(B?.ethernet)],
      ['Coverage', text(A?.coverage), text(B?.coverage)],
      ['Device capacity', text(A?.devices), text(B?.devices)],
      ['Price', text(A?.price), text(B?.price)]
    ];

    return [
      ['Provider', text(A?.name), text(B?.name)],
      ['Technology', text(A?.tech), text(B?.tech)],
      ['Available plans', `${A?.plans?.length || 0} plans`, `${B?.plans?.length || 0} plans`],
      ['Plan selected', selectedPlanA ? planLabel(selectedPlanA) : 'All plans', selectedPlanB ? planLabel(selectedPlanB) : 'All plans'],
      ['Download', selectedPlanA?.speed ? `${selectedPlanA.speed} Mbps` : 'See available plans', selectedPlanB?.speed ? `${selectedPlanB.speed} Mbps` : 'See available plans'],
      ['Upload', selectedPlanA?.upload ? `${selectedPlanA.upload} Mbps` : 'See available plans', selectedPlanB?.upload ? `${selectedPlanB.upload} Mbps` : 'See available plans'],
      ['Price', selectedPlanA ? money(selectedPlanA.price) : 'Plan dependent', selectedPlanB ? money(selectedPlanB.price) : 'Plan dependent'],
      ['Included router', selectedPlanA?.router || (A?.plans?.map(p => p.router).filter(Boolean).join(' / ') || '—'), selectedPlanB?.router || (B?.plans?.map(p => p.router).filter(Boolean).join(' / ') || '—')],
      ['Data', selectedPlanA?.data || 'Plan dependent', selectedPlanB?.data || 'Plan dependent'],
      ['Suitable for', selectedPlanA?.suitable || 'Multiple home-use plans', selectedPlanB?.suitable || 'Multiple home-use plans']
    ];
  }, [category, A, B, selectedPlanA, selectedPlanB]);

  const label = item => category === 'networks' ? item?.name : category === 'routers' ? item?.model : item?.name;
  const title = category === 'networks' ? 'Compare mobile networks' : category === 'routers' ? 'Compare routers & Wi-Fi' : 'Compare broadband providers';

  return <div className="page comparePage">
    <SectionTitle eyebrow="COMPARISON" title={title} text="Choose the type first, then compare two providers, networks or router models. Broadband speed is optional, not the primary selector."/>

    <div className="compareCategories twoCompareCategories">
      <button className={category === 'networks' ? 'compareCategory active' : 'compareCategory'} onClick={() => switchCategory('networks')}>
        <Signal size={20}/><span><b>Mobile Networks</b><small>Jio · Airtel · Vi · BSNL</small></span>
      </button>
      <button className={category !== 'networks' ? 'compareCategory active' : 'compareCategory'} onClick={() => switchCategory('broadband')}>
        <Wifi size={20}/><span><b>Broadband & Routers</b><small>Fiber providers and Wi-Fi hardware</small></span>
      </button>
    </div>

    {category !== 'networks' && <div className="compareSubtabs">
      <button className={category === 'broadband' ? 'active' : ''} onClick={() => switchCategory('broadband')}><Wifi size={16}/> Broadband / Fiber</button>
      <button className={category === 'routers' ? 'active' : ''} onClick={() => switchCategory('routers')}><Router size={16}/> Routers / Wi-Fi</button>
    </div>}

    {category === 'broadband' ? <div className="providerCompareControls">
      <div className="compareSideControl">
        <span className="compareSideLabel">Broadband A</span>
        <ProviderSelector value={providerA} exclude={providerB} onChange={id => changeProvider('A', id)}/>
        <label>Specific plan <span>(optional)</span><select value={planA} onChange={e => setPlanA(e.target.value)}>
          <option value="">All plans</option>
          {A?.plans?.map(plan => <option key={plan.id} value={plan.id}>{planLabel(plan)} · ₹{plan.price}</option>)}
        </select></label>
      </div>
      <ArrowLeftRight className="compareArrow"/>
      <div className="compareSideControl">
        <span className="compareSideLabel">Broadband B</span>
        <ProviderSelector value={providerB} exclude={providerA} onChange={id => changeProvider('B', id)}/>
        <label>Specific plan <span>(optional)</span><select value={planB} onChange={e => setPlanB(e.target.value)}>
          <option value="">All plans</option>
          {B?.plans?.map(plan => <option key={plan.id} value={plan.id}>{planLabel(plan)} · ₹{plan.price}</option>)}
        </select></label>
      </div>
    </div> : <div className="compareSelect">
      <label>{category === 'routers' ? 'Router A' : 'Network A'}<select value={A?.id || ''} onChange={e => category === 'routers' ? setRouterA(e.target.value) : setNetworkA(e.target.value)}>
        {(category === 'routers' ? routers : mobiles).map(x => <option key={x.id} value={x.id}>{category === 'routers' ? `${x.brand} ${x.model}` : x.name}</option>)}
      </select></label>
      <ArrowLeftRight/>
      <label>{category === 'routers' ? 'Router B' : 'Network B'}<select value={B?.id || ''} onChange={e => category === 'routers' ? setRouterB(e.target.value) : setNetworkB(e.target.value)}>
        {(category === 'routers' ? routers : mobiles).map(x => <option key={x.id} value={x.id}>{category === 'routers' ? `${x.brand} ${x.model}` : x.name}</option>)}
      </select></label>
    </div>}

    <div className="tableWrap"><table><thead><tr><th>Feature</th><th>{label(A)}</th><th>{label(B)}</th></tr></thead><tbody>{rows.map(r => <tr key={r[0]}><td><b>{r[0]}</b></td><td>{r[1]}</td><td>{r[2]}</td></tr>)}</tbody></table></div>

    <section className="section compact"><SectionTitle eyebrow="KEY DIFFERENCES" title="See what actually changes"/>
      <div className="diffgrid">
        <div className="card"><Pill>Option A</Pill><h3>{label(A)}</h3><p className="muted">{category === 'networks' ? `${A?.speed} Mbps estimated speed · ${A?.latency} ms latency.` : category === 'routers' ? `${A?.gen} · ${A?.coverage} coverage · ${A?.devices} devices.` : `${A?.plans?.length || 0} plans · ${selectedPlanA ? `${selectedPlanA.speed} Mbps · ₹${selectedPlanA.price}/month · ${selectedPlanA.router}` : 'speed and plan price shown only when selected'}.`}</p></div>
        <div className="card"><Pill>Option B</Pill><h3>{label(B)}</h3><p className="muted">{category === 'networks' ? `${B?.speed} Mbps estimated speed · ${B?.latency} ms latency.` : category === 'routers' ? `${B?.gen} · ${B?.coverage} coverage · ${B?.devices} devices.` : `${B?.plans?.length || 0} plans · ${selectedPlanB ? `${selectedPlanB.speed} Mbps · ₹${selectedPlanB.price}/month · ${selectedPlanB.router}` : 'speed and plan price shown only when selected'}.`}</p></div>
      </div>
      <div className="actionrow"><Button variant="outline" onClick={() => navigator.clipboard?.writeText(window.location.href)}><Share2 size={16}/> Share</Button><Button variant="secondary" onClick={() => window.print()}><Download size={16}/> Export / Print</Button></div>
    </section>
  </div>;
}
