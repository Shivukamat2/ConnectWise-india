function clamp(n,min,max){return Math.max(min,Math.min(max,n));}

export function runDiagnostic({plan=300,distance=8,walls=1,devices=5,interference=25,band='5 GHz',type='wifi',router='Wi-Fi 6 Gateway'}){
  const d=Math.max(0,Number(distance)||0), w=Math.max(0,Number(walls)||0), dev=Math.max(0,Number(devices)||0), int=clamp(Number(interference)||0,0,100);
  if(type==='cellular'){
    const rsrp=clamp(-72-d*1.6-int*.12,-125,-70);
    const rsrq=clamp(-7-int*.06-w*.5,-25,-5);
    const sinr=clamp(24-int*.18-d*.18,0,30);
    const load=clamp(Math.round(28+dev*3+int*.4),5,98);
    const speed=Math.max(5,Math.round(Math.min(plan,plan*(.58+sinr/80)*(1-load/160))));
    const ping=Math.round(18+d*2.2+int*.12);
    const jitter=Math.max(2,Math.round(ping*.14+int*.03));
    const loss=+clamp((100-sinr)*.012+load*.025,0.1,8).toFixed(1);
    const health=clamp(Math.round(speed/Math.max(plan,1)*45+(100-loss*6)*.2+(100-load)*.35),20,99);
    return {type,download:speed,upload:Math.round(speed*.28),ping,jitter,packetLoss:loss,signal:Math.round(rsrp),channelUtilization:load,health,band,rsrp:Math.round(rsrp),rsrq:Math.round(rsrq),sinr:Math.round(sinr),router:'5G modem / CPE'};
  }

  const bandPenalty=band==='2.4 GHz'?2.5:band==='6 GHz'?1.2:0;
  const signal=clamp(-42-d*1.45-w*(4+bandPenalty)-int*.12,-98,-35);
  const signalFactor=clamp(1-(Math.abs(signal)-42)/100,.35,1);
  const deviceFactor=clamp(1-dev*.022,.58,1);
  const interferenceFactor=clamp(1-int/220,.55,1);
  const speed=Math.max(8,Math.round(Math.min(plan,plan*signalFactor*deviceFactor*interferenceFactor)));
  const ping=Math.round(7+d*1.8+w*2.5+int*.08);
  const jitter=Math.max(2,Math.round(ping*.18+int*.025));
  const loss=+clamp(int*.012+dev*.035+Math.max(0,Math.abs(signal)-72)*.035,.05,6).toFixed(1);
  const utilization=clamp(Math.round(22+dev*4+int*.45),5,96);
  const health=clamp(Math.round(speed/Math.max(plan,1)*55+(100-loss*5)*.2+(100-utilization)*.25),20,99);
  return {type,download:speed,upload:Math.round(speed*.34),ping,jitter,packetLoss:loss,signal:Math.round(signal),channelUtilization:utilization,health,band,rsrp:Math.round(signal-31),rsrq:Math.round(-8-int*.03),sinr:Math.max(2,Math.round(23-int*.18)),router};
}

export function runRouterDiagnostic({router='Wi-Fi 6 Router',band='5 GHz',distance=8,walls=1,devices=5,interference=25,coverage=80}){
  const basePlan=1000;
  const result=runDiagnostic({plan:basePlan,distance,walls,devices,interference,band,type:'wifi',router});
  const coverageScore=clamp(Math.round(Number(coverage)||80)-Math.round(Math.max(0,distance-10)*2)-walls*3,20,99);
  const routerHealth=clamp(Math.round(result.health*.55+coverageScore*.25+(100-result.channelUtilization)*.2),20,99);
  const status=routerHealth>=85?'Excellent':routerHealth>=70?'Good':routerHealth>=50?'Needs attention':'Poor';
  return {...result,routerHealth,coverageScore,status,router};
}
