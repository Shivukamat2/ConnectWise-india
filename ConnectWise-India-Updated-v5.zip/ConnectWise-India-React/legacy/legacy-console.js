tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        noc: {
                            bg: '#080d16',
                            panel: '#111827',
                            panelAlt: '#172033',
                            border: '#1f2937',
                            borderBright: '#374151',
                            accentBlue: '#3b82f6',
                            accentCyan: '#06b6d4',
                            statusGreen: '#22c55e',
                            statusAmber: '#f59e0b',
                            statusRed: '#ef4444',
                            textMuted: '#9ca3af',
                            textBright: '#f3f4f6'
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace']
                    }
                }
            }
        }
    </script>
    <style>
        body {
            background-color: #080d16;
            color: #f3f4f6;
            font-family: 'Inter', sans-serif;
        }
        .font-mono {
            font-family: 'JetBrains Mono', monospace;
        }
        /* Custom scrollbar for NOC console aesthetics */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #080d16;
        }
        ::-webkit-scrollbar-thumb {
            background: #1f2937;
            border-radius: 3px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #374151;
        }
        .pulse-live {
            box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.4);
            animation: pulse-dot 2s infinite;
        }
        @keyframes pulse-dot {
            0% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.4); }
            70% { box-shadow: 0 0 0 8px rgba(34, 197, 94, 0); }
            100% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
        }
        .gauge-ring {
            transition: stroke-dashoffset 0.5s ease-in-out;
        }
    </style>
</head>
<body class="min-h-screen flex flex-col bg-noc-bg text-gray-200 antialiased selection:bg-noc-accentBlue selection:text-white">

    <!-- TOP HEADER -->
    <header class="bg-noc-panel border-b border-noc-border sticky top-0 z-40 shadow-md px-4 py-3">
        <div class="max-w-7xl mx-auto flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            
            <!-- Left Header Title Block -->
            <div class="flex flex-col">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="activity" class="w-6 h-6 text-noc-accentCyan"></i>
                    <h1 class="text-lg md:text-xl font-bold tracking-tight text-white flex items-center gap-2">
                        Indian Telecom Network & Router Diagnostic Console
                    </h1>
                    <span class="px-2 py-0.5 text-[10px] font-mono font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded uppercase tracking-wider">
                        SIMULATION MODE
                    </span>
                </div>
                <p class="text-xs text-noc-textMuted mt-0.5 flex items-center gap-1.5">
                    <span>Fiber Broadband • Wi-Fi Spectrum • 4G/5G Cellular • Router Performance • Network Comparison</span>
                </p>
            </div>

            <!-- Right Controls & Disclaimer Label -->
            <div class="flex flex-wrap items-center gap-2 lg:gap-3 text-xs">
                <div class="hidden sm:flex items-center gap-1.5 bg-noc-bg border border-noc-border rounded-lg px-2.5 py-1 text-noc-textMuted">
                    <i data-lucide="info" class="w-3.5 h-3.5 text-noc-accentBlue"></i>
                    <span class="font-mono text-[11px]">Demo telemetry • Values are simulated/estimated</span>
                </div>
                
                <div class="relative">
                    <input type="text" id="globalSearch" placeholder="Search routers, ISPs, bands..." class="bg-noc-bg border border-noc-border text-white text-xs rounded-lg pl-8 pr-3 py-1.5 focus:outline-none focus:border-noc-accentBlue w-36 sm:w-48 transition-all">
                    <i data-lucide="search" class="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2.5"></i>
                </div>

                <button onclick="runGlobalDiagnostic()" class="flex items-center gap-1.5 bg-noc-accentBlue hover:bg-blue-600 text-white font-medium px-3 py-1.5 rounded-lg transition-colors shadow-sm">
                    <i data-lucide="play" class="w-3.5 h-3.5"></i>
                    <span>Run Diagnostic</span>
                </button>

                <button onclick="openReportModal()" class="flex items-center gap-1.5 bg-noc-panelAlt hover:bg-gray-800 border border-noc-borderBright text-gray-200 font-medium px-3 py-1.5 rounded-lg transition-colors">
                    <i data-lucide="file-text" class="w-3.5 h-3.5 text-noc-accentCyan"></i>
                    <span>Export Report</span>
                </button>
            </div>
        </div>
    </header>

    <!-- NAVIGATION TABS -->
    <nav class="bg-noc-bg border-b border-noc-border px-4 sticky top-[57px] z-30">
        <div class="max-w-7xl mx-auto flex items-center overflow-x-auto no-scrollbar gap-1 text-sm font-medium">
            <button onclick="switchTab('overview')" id="tab-overview" class="tab-btn active border-b-2 border-noc-accentBlue text-noc-accentBlue px-4 py-3 flex items-center gap-2 whitespace-nowrap transition-colors">
                <i data-lucide="layout-dashboard" class="w-4 h-4"></i>
                <span>1. Network Overview</span>
            </button>
            <button onclick="switchTab('operators')" id="tab-operators" class="tab-btn border-b-2 border-transparent text-noc-textMuted hover:text-gray-200 px-4 py-3 flex items-center gap-2 whitespace-nowrap transition-colors">
                <i data-lucide="tower-control" class="w-4 h-4"></i>
                <span>2. ISP / Mobile Operators</span>
            </button>
            <button onclick="switchTab('routers')" id="tab-routers" class="tab-btn border-b-2 border-transparent text-noc-textMuted hover:text-gray-200 px-4 py-3 flex items-center gap-2 whitespace-nowrap transition-colors">
                <i data-lucide="router" class="w-4 h-4"></i>
                <span>3. Routers & CPE</span>
            </button>
            <button onclick="switchTab('comparison')" id="tab-comparison" class="tab-btn border-b-2 border-transparent text-noc-textMuted hover:text-gray-200 px-4 py-3 flex items-center gap-2 whitespace-nowrap transition-colors">
                <i data-lucide="git-compare" class="w-4 h-4"></i>
                <span>4. Comparison Engine</span>
            </button>
        </div>
    </nav>

    <!-- MAIN BODY CONTENT CONTAINER -->
    <main class="flex-1 max-w-7xl w-full mx-auto p-4 space-y-4">

        <!-- ========================================================= -->
        <!-- TAB 1: NETWORK OVERVIEW -->
        <!-- ========================================================= -->
        <section id="content-overview" class="space-y-4">
            
            <!-- Sub-Mode Selection & Location Bar -->
            <div class="bg-noc-panel border border-noc-border p-3 rounded-xl flex flex-col md:flex-row items-center justify-between gap-3 shadow-sm">
                <!-- Selectable Modes -->
                <div class="flex items-center bg-noc-bg p-1 rounded-lg border border-noc-border w-full md:w-auto">
                    <button onclick="setOverviewMode('fiber')" id="btn-mode-fiber" class="flex-1 md:flex-none px-4 py-1.5 rounded-md font-semibold text-xs transition-all flex items-center justify-center gap-2 bg-noc-accentBlue text-white shadow">
                        <i data-lucide="wifi" class="w-3.5 h-3.5"></i>
                        <span>FIBER / WI-FI OPTICAL</span>
                    </button>
                    <button onclick="setOverviewMode('cellular')" id="btn-mode-cellular" class="flex-1 md:flex-none px-4 py-1.5 rounded-md font-semibold text-xs transition-all flex items-center justify-center gap-2 text-noc-textMuted hover:text-white">
                        <i data-lucide="radio-tower" class="w-3.5 h-3.5"></i>
                        <span>CELLULAR 4G / 5G</span>
                    </button>
                </div>

                <!-- Global Simulation Location Profile Selector -->
                <div class="flex items-center gap-2 w-full md:w-auto justify-end">
                    <label class="text-xs text-noc-textMuted font-mono flex items-center gap-1.5 whitespace-nowrap">
                        <i data-lucide="map-pin" class="w-3.5 h-3.5 text-noc-accentCyan"></i>
                        Location Profile:
                    </label>
                    <select id="locationProfileSelect" onchange="updateLocationProfile()" class="bg-noc-bg border border-noc-border text-white text-xs font-mono rounded-lg px-3 py-1.5 focus:border-noc-accentCyan focus:outline-none w-full md:w-48">
                        <option value="bengaluru">Bengaluru Urban</option>
                        <option value="mumbai">Mumbai Urban</option>
                        <option value="delhi">Delhi NCR</option>
                        <option value="chennai">Chennai Urban</option>
                        <option value="hyderabad">Hyderabad Urban</option>
                        <option value="pune">Pune Urban</option>
                        <option value="rural">Rural / Semi-Urban</option>
                        <option value="custom">Custom Simulation</option>
                    </select>
                </div>
            </div>

            <!-- VIEW A: FIBER / WI-FI CONTAINER -->
            <div id="view-fiber" class="grid grid-cols-1 lg:grid-cols-12 gap-4">
                
                <!-- LEFT PANEL: Detected / Simulated Wi-Fi Environment -->
                <div class="lg:col-span-4 bg-noc-panel border border-noc-border rounded-xl p-4 flex flex-col justify-between shadow-sm">
                    <div>
                        <div class="flex items-center justify-between pb-3 border-b border-noc-border mb-3">
                            <h2 class="text-sm font-bold text-white flex items-center gap-2">
                                <i data-lucide="wifi" class="w-4 h-4 text-noc-accentBlue"></i>
                                Detected / Simulated Wi-Fi Environment
                            </h2>
                            <span class="text-[10px] font-mono bg-blue-500/10 text-noc-accentBlue px-2 py-0.5 rounded border border-blue-500/20">2.4 / 5 GHz</span>
                        </div>
                        <p class="text-xs text-noc-textMuted mb-3">Select a simulated network to inspect localized telemetry parameters.</p>
                        
                        <!-- List of Networks -->
                        <div class="space-y-2 text-xs font-mono" id="wifi-network-list">
                            <!-- JS will populate Wi-Fi items here -->
                        </div>
                    </div>

                    <div class="mt-4 pt-3 border-t border-noc-border text-[11px] text-noc-textMuted flex items-center justify-between">
                        <span>Spectrum Density: <strong class="text-emerald-400 font-mono">Moderate</strong></span>
                        <span>Noise Floor: <strong class="text-gray-300 font-mono">-92 dBm</strong></span>
                    </div>
                </div>

                <!-- RIGHT PANEL: Connection Diagnostics & Interactive Router Simulator -->
                <div class="lg:col-span-8 space-y-4">
                    
                    <!-- Top Summary Bar / Gauges -->
                    <div class="bg-noc-panel border border-noc-border rounded-xl p-4 shadow-sm">
                        <div class="flex items-center justify-between mb-4 pb-2 border-b border-noc-border">
                            <h2 class="text-sm font-bold text-white flex items-center gap-2">
                                <i data-lucide="cpu" class="w-4 h-4 text-noc-accentCyan"></i>
                                Active Link Diagnostics (Simulated Telemetry)
                            </h2>
                            <div class="flex items-center gap-2">
                                <span class="inline-block w-2 h-2 rounded-full bg-noc-statusGreen pulse-live"></span>
                                <span class="text-xs font-mono font-semibold text-noc-statusGreen" id="connectionHealthLabel">HEALTH: GOOD</span>
                            </div>
                        </div>

                        <!-- 4 Animated Gauge / Metric Tiles -->
                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                            
                            <!-- Download Throughput -->
                            <div class="bg-noc-panelAlt p-3 rounded-lg border border-noc-border">
                                <span class="text-[11px] text-noc-textMuted font-medium block mb-1">Estimated Download</span>
                                <div class="font-mono text-xl sm:text-2xl font-bold text-noc-accentBlue" id="gaugeDownload">138.4 <span class="text-xs text-gray-400">Mbps</span></div>
                                <div class="w-full bg-gray-800 h-1.5 rounded-full mt-2 overflow-hidden">
                                    <div id="barDownload" class="bg-noc-accentBlue h-full rounded-full transition-all duration-500" style="width: 70%"></div>
                                </div>
                                <span class="text-[10px] text-gray-400 mt-1 block font-mono">Plan: <span id="lblPlanSpeed">150</span> Mbps</span>
                            </div>

                            <!-- Signal Strength -->
                            <div class="bg-noc-panelAlt p-3 rounded-lg border border-noc-border">
                                <span class="text-[11px] text-noc-textMuted font-medium block mb-1">Wi-Fi RSSI</span>
                                <div class="font-mono text-xl sm:text-2xl font-bold text-emerald-400" id="gaugeRSSI">-56 <span class="text-xs text-gray-400">dBm</span></div>
                                <div class="w-full bg-gray-800 h-1.5 rounded-full mt-2 overflow-hidden">
                                    <div id="barRSSI" class="bg-emerald-400 h-full rounded-full transition-all duration-500" style="width: 82%"></div>
                                </div>
                                <span class="text-[10px] text-gray-400 mt-1 block font-mono">Noise: -92 dBm</span>
                            </div>

                            <!-- Ping / Latency -->
                            <div class="bg-noc-panelAlt p-3 rounded-lg border border-noc-border">
                                <span class="text-[11px] text-noc-textMuted font-medium block mb-1">Ping / Jitter</span>
                                <div class="font-mono text-xl sm:text-2xl font-bold text-cyan-400" id="gaugePing">18 <span class="text-xs text-gray-400">ms</span></div>
                                <div class="w-full bg-gray-800 h-1.5 rounded-full mt-2 overflow-hidden">
                                    <div id="barPing" class="bg-cyan-400 h-full rounded-full transition-all duration-500" style="width: 90%"></div>
                                </div>
                                <span class="text-[10px] text-gray-400 mt-1 block font-mono">Jitter: <span id="lblJitter">4</span> ms</span>
                            </div>

                            <!-- Packet Loss / Utilization -->
                            <div class="bg-noc-panelAlt p-3 rounded-lg border border-noc-border">
                                <span class="text-[11px] text-noc-textMuted font-medium block mb-1">Packet Loss</span>
                                <div class="font-mono text-xl sm:text-2xl font-bold text-amber-400" id="gaugeLoss">0.2 <span class="text-xs text-gray-400">%</span></div>
                                <div class="w-full bg-gray-800 h-1.5 rounded-full mt-2 overflow-hidden">
                                    <div id="barLoss" class="bg-amber-400 h-full rounded-full transition-all duration-500" style="width: 98%"></div>
                                </div>
                                <span class="text-[10px] text-gray-400 mt-1 block font-mono">Channel Util: <span id="lblChanUtil">34</span>%</span>
                            </div>

                        </div>
                    </div>

                    <!-- Interactive Router Telemetry Calculator Panel -->
                    <div class="bg-noc-panel border border-noc-border rounded-xl p-4 shadow-sm">
                        <h3 class="text-xs font-bold text-noc-accentCyan uppercase tracking-wider mb-3 flex items-center justify-between border-b border-noc-border pb-2">
                            <span class="flex items-center gap-1.5">
                                <i data-lucide="sliders" class="w-4 h-4"></i>
                                Router Diagnostic Simulation Parameters (Dynamic Mathematical Model)
                            </span>
                            <span class="text-[10px] font-mono text-noc-textMuted">Adjust sliders to re-calculate values</span>
                        </h3>

                        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                            
                            <div>
                                <label class="text-noc-textMuted block mb-1 font-mono">Internet Speed Plan</label>
                                <select id="simPlan" onchange="recalculateSimulation()" class="w-full bg-noc-bg border border-noc-border rounded p-1.5 font-mono text-white focus:outline-none focus:border-noc-accentBlue">
                                    <option value="30">30 Mbps (Basic)</option>
                                    <option value="100">100 Mbps (Standard)</option>
                                    <option value="150" selected>150 Mbps (Popular)</option>
                                    <option value="300">300 Mbps (Ultra)</option>
                                    <option value="500">500 Mbps (Gaming)</option>
                                    <option value="1000">1 Gbps (Gigabit Enterprise)</option>
                                </select>
                            </div>

                            <div>
                                <label class="text-noc-textMuted block mb-1 font-mono">Wi-Fi Router Hardware</label>
                                <select id="simRouter" onchange="recalculateSimulation()" class="w-full bg-noc-bg border border-noc-border rounded p-1.5 font-mono text-white focus:outline-none focus:border-noc-accentBlue">
                                    <option value="jio">Jio Home Gateway (Wi-Fi 5)</option>
                                    <option value="airtel">Airtel Xstream Fiber Router (Wi-Fi 5)</option>
                                    <option value="tplink">TP-Link AX3000 (Wi-Fi 6)</option>
                                    <option value="syrotech">Syrotech GPON ONT (Wi-Fi 4/5)</option>
                                    <option value="mesh">Mesh Wi-Fi 6 System</option>
                                </select>
                            </div>

                            <div>
                                <label class="text-noc-textMuted block mb-1 font-mono">Frequency Band</label>
                                <select id="simBand" onchange="recalculateSimulation()" class="w-full bg-noc-bg border border-noc-border rounded p-1.5 font-mono text-white focus:outline-none focus:border-noc-accentBlue">
                                    <option value="5" selected>5 GHz (High Speed, Lower Range)</option>
                                    <option value="2.4">2.4 GHz (Longer Range, Congested)</option>
                                </select>
                            </div>

                            <div>
                                <label class="text-noc-textMuted block mb-1 font-mono">Interference Level</label>
                                <select id="simInterference" onchange="recalculateSimulation()" class="w-full bg-noc-bg border border-noc-border rounded p-1.5 font-mono text-white focus:outline-none focus:border-noc-accentBlue">
                                    <option value="low">Low (Clear Spectrum)</option>
                                    <option value="med" selected>Medium (Typical Apartment)</option>
                                    <option value="high">High (Dense Urban Building)</option>
                                </select>
                            </div>

                            <!-- Sliders -->
                            <div class="sm:col-span-2">
                                <div class="flex justify-between font-mono text-[11px] mb-1">
                                    <span class="text-noc-textMuted">Distance to Router:</span>
                                    <span id="lblDistance" class="text-noc-accentBlue font-bold">4.5 meters</span>
                                </div>
                                <input type="range" id="simDistance" min="1" max="30" value="4.5" step="0.5" oninput="recalculateSimulation()" class="w-full accent-noc-accentBlue bg-noc-bg cursor-pointer">
                            </div>

                            <div>
                                <div class="flex justify-between font-mono text-[11px] mb-1">
                                    <span class="text-noc-textMuted">Concrete Walls:</span>
                                    <span id="lblWalls" class="text-noc-accentCyan font-bold">1 Wall</span>
                                </div>
                                <input type="range" id="simWalls" min="0" max="4" value="1" step="1" oninput="recalculateSimulation()" class="w-full accent-noc-accentCyan bg-noc-bg cursor-pointer">
                            </div>

                            <div>
                                <div class="flex justify-between font-mono text-[11px] mb-1">
                                    <span class="text-noc-textMuted">Connected Devices:</span>
                                    <span id="lblDevices" class="text-amber-400 font-bold">8 Devices</span>
                                </div>
                                <input type="range" id="simDevices" min="1" max="45" value="8" step="1" oninput="recalculateSimulation()" class="w-full accent-amber-400 bg-noc-bg cursor-pointer">
                            </div>

                        </div>
                    </div>

                    <!-- Dynamic Real-time Charts -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="bg-noc-panel border border-noc-border rounded-xl p-3">
                            <h4 class="text-xs font-semibold text-gray-300 mb-2 font-mono flex items-center justify-between">
                                <span>Throughput Timeline (Mbps)</span>
                                <span class="text-[10px] text-noc-textMuted">Live Stream</span>
                            </h4>
                            <div class="h-40">
                                <canvas id="chartThroughput"></canvas>
                            </div>
                        </div>

                        <div class="bg-noc-panel border border-noc-border rounded-xl p-3">
                            <h4 class="text-xs font-semibold text-gray-300 mb-2 font-mono flex items-center justify-between">
                                <span>Latency & Jitter (ms)</span>
                                <span class="text-[10px] text-noc-textMuted">ICMP Echo Telemetry</span>
                            </h4>
                            <div class="h-40">
                                <canvas id="chartLatency"></canvas>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- VIEW B: CELLULAR 4G / 5G CONTAINER (Hidden by default, toggled via JS) -->
            <div id="view-cellular" class="hidden space-y-4">
                
                <div class="bg-noc-panel border border-noc-border rounded-xl p-4">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-noc-border gap-2">
                        <div>
                            <h2 class="text-sm font-bold text-white flex items-center gap-2">
                                <i data-lucide="radio-tower" class="w-4 h-4 text-noc-accentCyan"></i>
                                Simulated Indian Cellular Site RF Matrix (5G SA / 5G NSA / 4G LTE)
                            </h2>
                            <p class="text-xs text-noc-textMuted mt-0.5">Cellular RF values are calculated based on simulated gNodeB distance, spectrum band propagation, and cell congestion.</p>
                        </div>
                        <span class="text-xs font-mono bg-cyan-500/10 text-noc-accentCyan px-2.5 py-1 rounded border border-cyan-500/20 whitespace-nowrap">
                            Location Profile: <strong id="cellularLocTitle">Bengaluru Urban</strong>
                        </span>
                    </div>

                    <!-- Cellular Site Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4" id="cellularGrid">
                        <!-- JS populated dynamic cell site cards -->
                    </div>

                    <div class="mt-4 p-3 bg-noc-panelAlt rounded-lg border border-noc-border text-xs text-noc-textMuted flex items-start gap-2">
                        <i data-lucide="alert-circle" class="w-4 h-4 text-amber-400 shrink-0 mt-0.5"></i>
                        <div>
                            <strong class="text-gray-200">Engineering Notice:</strong> Coverage depends on location, physical terrain, spectrum licensing, device modem capabilities, and live network load. RSRP (Reference Signal Received Power), RSRQ (Reference Signal Received Quality), and SINR (Signal-to-Interference-plus-Noise Ratio) reflect standard 3GPP LTE/5G NR telemetry guidelines.
                        </div>
                    </div>
                </div>

            </div>

            <!-- INTERACTIVE NETWORK TOPOLOGY DIAGRAM -->
            <div class="bg-noc-panel border border-noc-border rounded-xl p-4 shadow-sm">
                <div class="flex items-center justify-between border-b border-noc-border pb-3 mb-4">
                    <div>
                        <h3 class="text-sm font-bold text-white flex items-center gap-2">
                            <i data-lucide="network" class="w-4 h-4 text-noc-accentBlue"></i>
                            End-to-End Network Topology Architecture
                        </h3>
                        <p class="text-xs text-noc-textMuted">Click any node to inspect node protocol telemetry and routing details.</p>
                    </div>
                    <span class="text-xs font-mono bg-noc-panelAlt border border-noc-border text-gray-300 px-2.5 py-1 rounded">
                        Active Mode: <strong id="topologyModeTag" class="text-noc-accentBlue uppercase">Fiber FTTH</strong>
                    </span>
                </div>

                <div class="overflow-x-auto py-4">
                    <div class="min-w-[700px] flex items-center justify-between relative px-6" id="topologyNodesContainer">
                        <!-- Dynamically populated topology nodes -->
                    </div>
                </div>
            </div>

            <!-- SCROLLING REALTIME NETWORK ENGINEERING TERMINAL LOG -->
            <div class="bg-black/80 border border-noc-border rounded-xl p-3 font-mono text-xs shadow-inner">
                <div class="flex items-center justify-between border-b border-gray-800 pb-2 mb-2">
                    <div class="flex items-center gap-2 text-noc-textMuted">
                        <i data-lucide="terminal" class="w-3.5 h-3.5 text-emerald-400"></i>
                        <span class="text-gray-300 font-semibold">NOC Telemetry Event Log</span>
                    </div>
                    <span class="text-[10px] text-gray-500">Auto-refreshing 1000ms</span>
                </div>
                <div id="terminalLog" class="h-28 overflow-y-auto space-y-1 text-gray-400 font-mono text-[11px] leading-relaxed">
                    <!-- Logs injected via JS -->
                </div>
            </div>

        </section>

        <!-- ========================================================= -->
        <!-- TAB 2: ISP / MOBILE OPERATORS -->
        <!-- ========================================================= -->
        <section id="content-operators" class="hidden space-y-4">
            
            <div class="bg-noc-panel border border-noc-border p-4 rounded-xl">
                <h2 class="text-base font-bold text-white flex items-center gap-2">
                    <i data-lucide="tower-control" class="w-5 h-5 text-noc-accentBlue"></i>
                    Major Indian Telecom Operators & ISP Data Reference
                </h2>
                <p class="text-xs text-noc-textMuted mt-1">
                    Technical overview of spectrum bands, 5G architectural deployments (SA vs NSA), FTTH broadband plans, and coverage characteristics across India.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                <!-- JIO CARD -->
                <div class="bg-noc-panel border border-noc-border rounded-xl p-5 hover:border-blue-500/40 transition-all">
                    <div class="flex items-center justify-between border-b border-noc-border pb-3 mb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center font-bold text-blue-400 text-lg">
                                JIO
                            </div>
                            <div>
                                <h3 class="text-base font-bold text-white">Reliance Jio Infocomm</h3>
                                <span class="text-xs text-noc-accentBlue font-mono">Mobile: Jio True 5G • Fiber: JioFiber</span>
                            </div>
                        </div>
                        <span class="px-2 py-1 text-[10px] font-mono bg-blue-500/10 text-blue-400 border border-blue-500/30 rounded">
                            5G STANDALONE (SA)
                        </span>
                    </div>

                    <div class="space-y-3 text-xs">
                        <div>
                            <strong class="text-gray-300 font-mono block mb-1">5G Technology & Key Spectrum Bands:</strong>
                            <div class="flex flex-wrap gap-1.5 font-mono text-[11px]">
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-cyan-300">n28 (700 MHz - Coverage)</span>
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-cyan-300">n78 (3500 MHz - Capacity)</span>
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-cyan-300">n258 (26 GHz - mmWave)</span>
                            </div>
                        </div>

                        <p class="text-noc-textMuted leading-relaxed">
                            Jio operates a pure 5G Standalone (SA) architecture requiring no reliance on legacy 4G core networks. 5G availability varies by location, device hardware support, and physical propagation conditions.
                        </p>

                        <div class="border-t border-noc-border pt-3">
                            <strong class="text-gray-300 font-mono block mb-2">Popular JioFiber Broadband Speed Tiers:</strong>
                            <div class="grid grid-cols-2 gap-2 font-mono text-[11px]">
                                <div class="bg-noc-panelAlt p-2 rounded border border-noc-border">
                                    <div class="text-white font-bold">30 Mbps</div>
                                    <div class="text-noc-textMuted">₹399/mo + GST</div>
                                </div>
                                <div class="bg-noc-panelAlt p-2 rounded border border-noc-border">
                                    <div class="text-white font-bold">100 Mbps</div>
                                    <div class="text-noc-textMuted">₹699/mo + GST</div>
                                </div>
                                <div class="bg-noc-panelAlt p-2 rounded border border-noc-border">
                                    <div class="text-white font-bold">150 Mbps</div>
                                    <div class="text-noc-textMuted">₹999/mo + GST</div>
                                </div>
                                <div class="bg-noc-panelAlt p-2 rounded border border-noc-border">
                                    <div class="text-white font-bold">300 Mbps</div>
                                    <div class="text-noc-textMuted">₹1,499/mo + GST</div>
                                </div>
                            </div>
                            <span class="text-[10px] text-gray-500 mt-2 block italic">* Plan availability and pricing may vary by circle, location and local taxes.</span>
                        </div>
                    </div>
                </div>

                <!-- AIRTEL CARD -->
                <div class="bg-noc-panel border border-noc-border rounded-xl p-5 hover:border-red-500/40 transition-all">
                    <div class="flex items-center justify-between border-b border-noc-border pb-3 mb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-lg bg-red-600/20 border border-red-500/40 flex items-center justify-center font-bold text-red-400 text-lg">
                                AIR
                            </div>
                            <div>
                                <h3 class="text-base font-bold text-white">Bharti Airtel</h3>
                                <span class="text-xs text-red-400 font-mono">Mobile: Airtel 5G Plus • Fiber: Xstream Fiber</span>
                            </div>
                        </div>
                        <span class="px-2 py-1 text-[10px] font-mono bg-red-500/10 text-red-400 border border-red-500/30 rounded">
                            5G NON-STANDALONE (NSA)
                        </span>
                    </div>

                    <div class="space-y-3 text-xs">
                        <div>
                            <strong class="text-gray-300 font-mono block mb-1">5G Technology & Spectrum Bands:</strong>
                            <div class="flex flex-wrap gap-1.5 font-mono text-[11px]">
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-red-300">n78 (3500 MHz)</span>
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-red-300">1800 / 2100 MHz (Refarming)</span>
                            </div>
                        </div>

                        <p class="text-noc-textMuted leading-relaxed">
                            Airtel utilizes 5G Non-Standalone (NSA) technology leveraging existing LTE infrastructure for ultra-fast session setups. Observed/estimated performance depends on location, spectrum availability, handset model, and cell load.
                        </p>

                        <div class="border-t border-noc-border pt-3">
                            <strong class="text-gray-300 font-mono block mb-2">Airtel Xstream Fiber Speed Tiers:</strong>
                            <div class="grid grid-cols-2 gap-2 font-mono text-[11px]">
                                <div class="bg-noc-panelAlt p-2 rounded border border-noc-border">
                                    <div class="text-white font-bold">40 Mbps</div>
                                    <div class="text-noc-textMuted">Basic Plan</div>
                                </div>
                                <div class="bg-noc-panelAlt p-2 rounded border border-noc-border">
                                    <div class="text-white font-bold">100 Mbps</div>
                                    <div class="text-noc-textMuted">Standard Plan</div>
                                </div>
                                <div class="bg-noc-panelAlt p-2 rounded border border-noc-border">
                                    <div class="text-white font-bold">300 Mbps</div>
                                    <div class="text-noc-textMuted">Entertainment Plan</div>
                                </div>
                                <div class="bg-noc-panelAlt p-2 rounded border border-noc-border">
                                    <div class="text-white font-bold">1 Gbps</div>
                                    <div class="text-noc-textMuted">VIP Gigabit Plan</div>
                                </div>
                            </div>
                            <span class="text-[10px] text-gray-500 mt-2 block italic">* Pricing and availability vary by city and specific plan terms.</span>
                        </div>
                    </div>
                </div>

                <!-- VI CARD -->
                <div class="bg-noc-panel border border-noc-border rounded-xl p-5 hover:border-yellow-500/40 transition-all">
                    <div class="flex items-center justify-between border-b border-noc-border pb-3 mb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-lg bg-yellow-600/20 border border-yellow-500/40 flex items-center justify-center font-bold text-yellow-400 text-lg">
                                VI
                            </div>
                            <div>
                                <h3 class="text-base font-bold text-white">Vodafone Idea (Vi)</h3>
                                <span class="text-xs text-yellow-400 font-mono">Mobile: Vi 4G GIGAnet / Vi 5G Expansion</span>
                            </div>
                        </div>
                        <span class="px-2 py-1 text-[10px] font-mono bg-yellow-500/10 text-yellow-400 border border-yellow-500/30 rounded">
                            4G LTE + SELECT 5G
                        </span>
                    </div>

                    <div class="space-y-3 text-xs">
                        <div>
                            <strong class="text-gray-300 font-mono block mb-1">Key Spectrum & Deployment Status:</strong>
                            <div class="flex flex-wrap gap-1.5 font-mono text-[11px]">
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-yellow-300">B1 / B3 / B8 / B40 LTE</span>
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-yellow-300">n78 (Key Metro Circles)</span>
                            </div>
                        </div>

                        <p class="text-noc-textMuted leading-relaxed">
                            Vi continues deployment of high-capacity 4G LTE-Advanced refarming across priority circles. Vi announced continued 5G expansion across additional Indian cities during 2026. 5G availability is city/circle dependent.
                        </p>

                        <div class="border-t border-noc-border pt-3">
                            <div class="flex items-center justify-between text-noc-textMuted font-mono">
                                <span>5G Rollout Status (2026):</span>
                                <span class="text-yellow-400 font-bold">Expanding Metros</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- BSNL CARD -->
                <div class="bg-noc-panel border border-noc-border rounded-xl p-5 hover:border-emerald-500/40 transition-all">
                    <div class="flex items-center justify-between border-b border-noc-border pb-3 mb-4">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-lg bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center font-bold text-emerald-400 text-lg">
                                BSNL
                            </div>
                            <div>
                                <h3 class="text-base font-bold text-white">BSNL (Bharat Sanchar Nigam Ltd)</h3>
                                <span class="text-xs text-emerald-400 font-mono">Mobile: BSNL 4G • Fiber: Bharat Fiber (FTTH)</span>
                            </div>
                        </div>
                        <span class="px-2 py-1 text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded">
                            NATIVE 4G / FTTH FIBER
                        </span>
                    </div>

                    <div class="space-y-3 text-xs">
                        <div>
                            <strong class="text-gray-300 font-mono block mb-1">Key Spectrum & Infrastructure:</strong>
                            <div class="flex flex-wrap gap-1.5 font-mono text-[11px]">
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-emerald-300">B1 (2100 MHz)</span>
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-emerald-300">B8 (900 MHz)</span>
                                <span class="bg-noc-panelAlt border border-noc-border px-2 py-0.5 rounded text-emerald-300">Bharat Fiber GPON</span>
                            </div>
                        </div>

                        <p class="text-noc-textMuted leading-relaxed">
                            State-owned telecom provider deploying indigenous 4G stack nationwide alongside extensive pan-India Bharat Fiber GPON coverage. Mobile availability and performance vary significantly by location.
                        </p>

                        <div class="border-t border-noc-border pt-3">
                            <div class="flex items-center justify-between text-noc-textMuted font-mono">
                                <span>Bharat Fiber Coverage:</span>
                                <span class="text-emerald-400 font-bold">Pan-India Tier 1-3 & Rural</span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <!-- ========================================================= -->
        <!-- TAB 3: ROUTERS & CPE -->
        <!-- ========================================================= -->
        <section id="content-routers" class="hidden space-y-4">
            
            <div class="bg-noc-panel border border-noc-border p-4 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                    <h2 class="text-base font-bold text-white flex items-center gap-2">
                        <i data-lucide="router" class="w-5 h-5 text-noc-accentCyan"></i>
                        Router & Customer Premises Equipment (CPE) Database
                    </h2>
                    <p class="text-xs text-noc-textMuted mt-0.5">
                        Technical specifications and performance benchmarks comparing ISP-bundled ONTs with retail Wi-Fi 6 & 5G CPE hardware.
                    </p>
                </div>
                <!-- Filter Pills -->
                <div class="flex items-center gap-1.5 overflow-x-auto text-xs font-mono">
                    <button onclick="filterRouters('all')" class="router-filter-btn px-3 py-1 bg-noc-accentBlue text-white rounded">All Hardware</button>
                    <button onclick="filterRouters('ont')" class="router-filter-btn px-3 py-1 bg-noc-panelAlt border border-noc-border text-gray-300 hover:text-white rounded">Fiber ONTs</button>
                    <button onclick="filterRouters('wifi6')" class="router-filter-btn px-3 py-1 bg-noc-panelAlt border border-noc-border text-gray-300 hover:text-white rounded">Wi-Fi 6 Routers</button>
                    <button onclick="filterRouters('5gcpe')" class="router-filter-btn px-3 py-1 bg-noc-panelAlt border border-noc-border text-gray-300 hover:text-white rounded">5G CPEs</button>
                </div>
            </div>

            <!-- Router Cards Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" id="routerGrid">
                <!-- JS populated router cards -->
            </div>

        </section>

        <!-- ========================================================= -->
        <!-- TAB 4: COMPARISON ENGINE -->
        <!-- ========================================================= -->
        <section id="content-comparison" class="hidden space-y-4">
            
            <div class="bg-noc-panel border border-noc-border p-4 rounded-xl">
                <h2 class="text-base font-bold text-white flex items-center gap-2">
                    <i data-lucide="git-compare" class="w-5 h-5 text-noc-accentBlue"></i>
                    Interactive Network & Hardware Comparison Matrix
                </h2>
                <p class="text-xs text-noc-textMuted mt-1">
                    Select two operators, fiber broadband plans, or CPE router models to compare side-by-side technical parameters.
                </p>

                <!-- Selectors -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                    <div class="bg-noc-panelAlt p-3 rounded-lg border border-noc-border">
                        <label class="text-xs font-mono text-noc-accentBlue block mb-1.5">Select Entity A:</label>
                        <select id="compareA" onchange="renderComparison()" class="w-full bg-noc-bg border border-noc-border text-white text-xs font-mono rounded p-2 focus:outline-none focus:border-noc-accentBlue">
                            <option value="jio_5g">Jio True 5G (Mobile SA)</option>
                            <option value="airtel_5g">Airtel 5G Plus (Mobile NSA)</option>
                            <option value="vi_4g">Vi 4G / 5G Mobile</option>
                            <option value="bsnl_4g">BSNL 4G Mobile</option>
                            <option value="jio_fiber" selected>JioFiber 150 Mbps Plan</option>
                            <option value="airtel_fiber">Airtel Xstream 300 Mbps Plan</option>
                            <option value="tplink_ax3000">TP-Link AX3000 Wi-Fi 6 Router</option>
                        </select>
                    </div>

                    <div class="bg-noc-panelAlt p-3 rounded-lg border border-noc-border">
                        <label class="text-xs font-mono text-noc-accentCyan block mb-1.5">Select Entity B:</label>
                        <select id="compareB" onchange="renderComparison()" class="w-full bg-noc-bg border border-noc-border text-white text-xs font-mono rounded p-2 focus:outline-none focus:border-noc-accentCyan">
                            <option value="jio_5g">Jio True 5G (Mobile SA)</option>
                            <option value="airtel_5g" selected>Airtel 5G Plus (Mobile NSA)</option>
                            <option value="vi_4g">Vi 4G / 5G Mobile</option>
                            <option value="bsnl_4g">BSNL 4G Mobile</option>
                            <option value="jio_fiber">JioFiber 150 Mbps Plan</option>
                            <option value="airtel_fiber">Airtel Xstream 300 Mbps Plan</option>
                            <option value="tplink_ax3000">TP-Link AX3000 Wi-Fi 6 Router</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Dynamic Verdict Badges Container -->
            <div id="verdictBadges" class="flex flex-wrap gap-2">
                <!-- Injected via JS -->
            </div>

            <!-- Comparison Table -->
            <div class="bg-noc-panel border border-noc-border rounded-xl overflow-hidden shadow-sm">
                <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left font-mono">
                        <thead class="bg-noc-panelAlt text-noc-textMuted border-b border-noc-border">
                            <tr>
                                <th class="p-3 w-1/3">Parameter</th>
                                <th class="p-3 w-1/3 text-noc-accentBlue" id="thEntityA">Entity A</th>
                                <th class="p-3 w-1/3 text-noc-accentCyan" id="thEntityB">Entity B</th>
                            </tr>
                        </thead>
                        <tbody id="comparisonTableBody" class="divide-y divide-noc-border text-gray-200">
                            <!-- JS populated rows -->
                        </tbody>
                    </table>
                </div>
            </div>

        </section>

        <!-- DATA SOURCES & METHODOLOGY FOOTER SECTION -->
        <section class="bg-noc-panel border border-noc-border rounded-xl p-4 text-xs text-noc-textMuted space-y-2">
            <h4 class="font-bold text-white flex items-center gap-2 font-mono">
                <i data-lucide="book-open" class="w-4 h-4 text-noc-accentBlue"></i>
                Data Sources, Regulatory Compliance & Simulation Methodology
            </h4>
            <p>
                This diagnostic platform generates real-time telemetry using deterministic RF propagation formulas (Free Space Path Loss, Shadowing Models, and 3GPP TS 38.215 signal strength calculations). All tower IDs, cell site locations, spectrum allocations, and live throughput numbers represent <strong>simulated research estimates</strong>.
            </p>
            <div class="flex flex-wrap items-center gap-x-4 gap-y-1 font-mono text-[11px] pt-1">
                <span>Official References:</span>
                <a href="https://www.jio.com/5g/" target="_blank" class="text-noc-accentBlue hover:underline flex items-center gap-1">
                    Jio 5G Portal <i data-lucide="external-link" class="w-3 h-3"></i>
                </a>
                <a href="https://www.airtel.in/" target="_blank" class="text-noc-accentBlue hover:underline flex items-center gap-1">
                    Airtel Official <i data-lucide="external-link" class="w-3 h-3"></i>
                </a>
                <a href="https://www.myvi.in/5g-network" target="_blank" class="text-noc-accentBlue hover:underline flex items-center gap-1">
                    Vi 5G Updates <i data-lucide="external-link" class="w-3 h-3"></i>
                </a>
            </div>
        </section>

    </main>

    <!-- FOOTER BAR -->
    <footer class="bg-noc-panel border-t border-noc-border py-3 px-4 text-center text-xs text-noc-textMuted font-mono">
        <div class="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <div>
                © 2026 Telecom Diagnostic Simulation Console • Built for Engineering Research & Analytics
            </div>
            <div class="flex items-center gap-3">
                <button onclick="resetAllSimulations()" class="hover:text-white transition-colors">Reset Simulation Data</button>
                <span>•</span>
                <button onclick="exportJSONData()" class="hover:text-noc-accentBlue transition-colors">Export JSON Telemetry</button>
            </div>
        </div>
    </footer>

    <!-- REPORT MODAL -->
    <div id="reportModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-noc-panel border border-noc-border rounded-xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div class="p-4 border-b border-noc-border flex items-center justify-between bg-noc-panelAlt">
                <div class="flex items-center gap-2">
                    <i data-lucide="file-check" class="w-5 h-5 text-noc-accentCyan"></i>
                    <h3 class="font-bold text-white text-sm">Generated Network Diagnostic Audit Report</h3>
                </div>
                <button onclick="closeReportModal()" class="text-gray-400 hover:text-white">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <div class="p-5 overflow-y-auto space-y-4 text-xs font-mono" id="reportModalBody">
                <!-- JS content injected here -->
            </div>

            <div class="p-3 border-t border-noc-border bg-noc-panelAlt flex items-center justify-between">
                <span class="text-[11px] text-gray-400">Status: Audit Complete</span>
                <div class="flex items-center gap-2">
                    <button onclick="downloadCSVReport()" class="px-3 py-1.5 bg-noc-bg border border-noc-border text-gray-200 hover:text-white rounded text-xs font-medium flex items-center gap-1.5">
                        <i data-lucide="download" class="w-3.5 h-3.5"></i> Export CSV
                    </button>
                    <button onclick="window.print()" class="px-3 py-1.5 bg-noc-accentBlue text-white hover:bg-blue-600 rounded text-xs font-medium flex items-center gap-1.5">
                        <i data-lucide="printer" class="w-3.5 h-3.5"></i> Print Report
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- NODE DETAILS MODAL -->
    <div id="nodeModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-noc-panel border border-noc-border rounded-xl max-w-md w-full p-4 space-y-3 shadow-2xl">
            <div class="flex items-center justify-between border-b border-noc-border pb-2">
                <h3 class="font-bold text-white text-xs flex items-center gap-2 font-mono" id="nodeModalTitle">
                    <i data-lucide="server" class="w-4 h-4 text-noc-accentBlue"></i> Node Telemetry
                </h3>
                <button onclick="closeNodeModal()" class="text-gray-400 hover:text-white">
                    <i data-lucide="x" class="w-4 h-4"></i>
                </button>
            </div>
            <div class="text-xs space-y-2 font-mono text-gray-300" id="nodeModalContent">
                <!-- JS injected content -->
            </div>
            <button onclick="closeNodeModal()" class="w-full py-1.5 bg-noc-panelAlt border border-noc-border text-xs text-gray-300 rounded font-mono hover:bg-gray-800">
                Close Inspector
            </button>
        </div>
    </div>

    <!-- MAIN JAVASCRIPT LOGIC -->
    <script>
        // Initialize Lucide Icons
        lucide.createIcons();

        // Global State Variable Store
        const state = {
            currentTab: 'overview',
            overviewMode: 'fiber', // 'fiber' or 'cellular'
            location: 'bengaluru',
            selectedWifiIndex: 0,
            simParameters: {
                plan: 150,
                router: 'jio',
                band: '5',
                interference: 'med',
                distance: 4.5,
                walls: 1,
                devices: 8
            },
            calculatedMetrics: {
                download: 138.4,
                upload: 89.2,
                rssi: -56,
                ping: 18,
                jitter: 4,
                loss: 0.2,
                chanUtil: 34,
                health: 'GOOD'
            }
        };

        // Static Datasets
        const wifiNetworks = [
            { ssid: 'Airtel_Xstream_5G', band: '5 GHz', channel: 149, rssi: -48, noise: -91, security: 'WPA2/WPA3', status: 'Excellent' },
            { ssid: 'JioFiber_Home_5G', band: '5 GHz', channel: 44, rssi: -56, noise: -92, security: 'WPA2/WPA3', status: 'Good' },
            { ssid: 'JioFiber_Home_2.4G', band: '2.4 GHz', channel: 6, rssi: -62, noise: -89, security: 'WPA2', status: 'Fair' },
            { ssid: 'ACT_Fibernet_5G', band: '5 GHz', channel: 36, rssi: -65, noise: -93, security: 'WPA3', status: 'Fair' },
            { ssid: 'BSNL_FTTH_HighSpeed', band: '2.4 GHz', channel: 11, rssi: -71, noise: -88, security: 'WPA2', status: 'Moderate' },
            { ssid: 'TPLink_Home_Network', band: '5 GHz', channel: 157, rssi: -74, noise: -90, security: 'WPA2', status: 'Weak' },
            { ssid: 'Netgear_Guest_Zone', band: '2.4 GHz', channel: 1, rssi: -82, noise: -87, security: 'Open/Portal', status: 'Poor' }
        ];

        const locationCellProfiles = {
            bengaluru: [
                { operator: 'Jio', site: 'Simulated Cell Site BLR-104', tech: '5G SA', band: 'n78 (3500 MHz)', dist: '0.8 km', rsrp: -82, rsrq: -10, sinr: 18, dl: 420, ul: 55, ping: 19, load: 42 },
                { operator: 'Airtel', site: 'Simulated Cell Site BLR-209', tech: '5G NSA', band: 'n78 (3500 MHz)', dist: '1.1 km', rsrp: -88, rsrq: -11, sinr: 15, dl: 350, ul: 42, ping: 21, load: 48 },
                { operator: 'Vi', site: 'Simulated Cell Site BLR-312', tech: '5G / 4G LTE', band: 'n78 / B1', dist: '1.4 km', rsrp: -94, rsrq: -13, sinr: 10, dl: 220, ul: 28, ping: 25, load: 62 },
                { operator: 'BSNL', site: 'Simulated Cell Site BLR-401', tech: '4G LTE', band: 'B1 / B8', dist: '1.9 km', rsrp: -91, rsrq: -12, sinr: 9, dl: 35, ul: 12, ping: 35, load: 55 }
            ],
            mumbai: [
                { operator: 'Jio', site: 'Simulated Cell Site BOM-881', tech: '5G SA', band: 'n78 / n28', dist: '0.6 km', rsrp: -79, rsrq: -9, sinr: 21, dl: 480, ul: 62, ping: 17, load: 50 },
                { operator: 'Airtel', site: 'Simulated Cell Site BOM-442', tech: '5G NSA', band: 'n78 (3500 MHz)', dist: '0.9 km', rsrp: -84, rsrq: -10, sinr: 17, dl: 390, ul: 48, ping: 19, load: 54 },
                { operator: 'Vi', site: 'Simulated Cell Site BOM-105', tech: '5G / 4G LTE', band: 'n78 / B3', dist: '1.2 km', rsrp: -91, rsrq: -12, sinr: 12, dl: 250, ul: 31, ping: 23, load: 68 },
                { operator: 'BSNL', site: 'Simulated Cell Site BOM-092', tech: '4G LTE', band: 'B1 / B8', dist: '2.1 km', rsrp: -95, rsrq: -14, sinr: 7, dl: 28, ul: 9, ping: 40, load: 60 }
            ],
            delhi: [
                { operator: 'Jio', site: 'Simulated Cell Site DEL-512', tech: '5G SA', band: 'n78 (3500 MHz)', dist: '0.7 km', rsrp: -80, rsrq: -9, sinr: 20, dl: 450, ul: 58, ping: 18, load: 46 },
                { operator: 'Airtel', site: 'Simulated Cell Site DEL-901', tech: '5G NSA', band: 'n78 (3500 MHz)', dist: '1.0 km', rsrp: -86, rsrq: -11, sinr: 16, dl: 370, ul: 44, ping: 20, load: 51 },
                { operator: 'Vi', site: 'Simulated Cell Site DEL-304', tech: '4G LTE', band: 'B1 / B3 / B8', dist: '1.5 km', rsrp: -93, rsrq: -13, sinr: 11, dl: 180, ul: 24, ping: 26, load: 70 },
                { operator: 'BSNL', site: 'Simulated Cell Site DEL-771', tech: '4G LTE', band: 'B1 / B8', dist: '2.0 km', rsrp: -92, rsrq: -12, sinr: 8, dl: 32, ul: 10, ping: 38, load: 58 }
            ],
            rural: [
                { operator: 'Jio', site: 'Simulated Cell Site RUR-011', tech: '5G SA / 4G', band: 'n28 (700 MHz)', dist: '3.5 km', rsrp: -101, rsrq: -14, sinr: 7, dl: 85, ul: 14, ping: 32, load: 25 },
                { operator: 'Airtel', site: 'Simulated Cell Site RUR-024', tech: '4G LTE', band: 'B3 (1800 MHz)', dist: '3.8 km', rsrp: -104, rsrq: -15, sinr: 5, dl: 62, ul: 11, ping: 36, load: 30 },
                { operator: 'Vi', site: 'Simulated Cell Site RUR-089', tech: '4G LTE', band: 'B8 (900 MHz)', dist: '4.2 km', rsrp: -108, rsrq: -16, sinr: 4, dl: 41, ul: 7, ping: 42, load: 35 },
                { operator: 'BSNL', site: 'Simulated Cell Site RUR-990', tech: '4G LTE', band: 'B1 (2100 MHz)', dist: '2.8 km', rsrp: -97, rsrq: -13, sinr: 8, dl: 48, ul: 15, ping: 34, load: 20 }
            ]
        };
        // Fallback for other city selections to use Bengaluru Urban baseline with small offsets
        ['chennai', 'hyderabad', 'pune', 'custom'].forEach(loc => {
            if (!locationCellProfiles[loc]) locationCellProfiles[loc] = locationCellProfiles.bengaluru;
        });

        const routerDatabase = [
            { id: 'jio_gw', name: 'Jio Home Gateway', cat: 'ont', categoryLabel: 'ISP Gateway', wifiGen: '802.11ac (Wi-Fi 5)', dualBand: '2.4 GHz + 5 GHz', ports: '4x GbE', wan: 'Optical Fiber GPON', thSpeed: '1200 Mbps', practicalSpeed: '140-280 Mbps', mesh: 'No', price: 'Bundled with Plan', bestFor: 'Standard Home FTTH' },
            { id: 'airtel_gw', name: 'Airtel Xstream Fiber Router', cat: 'ont', categoryLabel: 'ISP Gateway', wifiGen: '802.11ac (Wi-Fi 5)', dualBand: '2.4 GHz + 5 GHz', ports: '4x GbE', wan: 'XPON / FTTH', thSpeed: '1200 Mbps', practicalSpeed: '150-290 Mbps', mesh: 'Mesh Capable', price: 'Bundled with Plan', bestFor: 'High-speed FTTH' },
            { id: 'syrotech_ont', name: 'Syrotech GPON/XPON ONT', cat: 'ont', categoryLabel: 'Fiber ONT', wifiGen: '802.11n / ac', dualBand: '2.4 GHz Single / Dual', ports: '1x/2x GE', wan: 'SC/UPC Fiber', thSpeed: '300-1200 Mbps', practicalSpeed: '80-180 Mbps', mesh: 'No', price: 'Typical ₹1,800 - ₹2,500', bestFor: 'Local Cable ISP FTTH' },
            { id: 'netlink_ont', name: 'Netlink XPON ONT Terminal', cat: 'ont', categoryLabel: 'Fiber ONT', wifiGen: '802.11n / ac', dualBand: '2.4 GHz / Dual', ports: '1x GE + Voice', wan: 'PON Optical', thSpeed: '300-1200 Mbps', practicalSpeed: '75-175 Mbps', mesh: 'No', price: 'Typical ₹1,600 - ₹2,200', bestFor: 'BSNL / Local Fiber' },
            { id: 'tplink_ax3000', name: 'TP-Link AX3000 Wi-Fi 6', cat: 'wifi6', categoryLabel: 'Wi-Fi Router', wifiGen: '802.11ax (Wi-Fi 6)', dualBand: '2.4 GHz + 5 GHz', ports: '4x GbE LAN, 1x WAN', wan: 'Ethernet RJ45', thSpeed: '3000 Mbps', practicalSpeed: '450-850 Mbps', mesh: 'OneMesh Supported', price: 'Typical ₹4,999', bestFor: 'Medium/Large Home Gaming' },
            { id: 'tplink_5g', name: 'TP-Link Deco 5G CPE', cat: '5gcpe', categoryLabel: '5G CPE Router', wifiGen: '802.11ax (Wi-Fi 6)', dualBand: '2.4 GHz + 5 GHz', ports: '2x 2.5GbE', wan: '5G SIM Slot (n78/n28)', thSpeed: '3400 Mbps Cellular', practicalSpeed: '300-700 Mbps 5G', mesh: 'Full Deco Mesh', price: 'Typical ₹22,000+', bestFor: 'Fix Wireless 5G Home' },
            { id: 'zte_5g', name: 'ZTE MC801A 5G Indoor CPE', cat: '5gcpe', categoryLabel: '5G CPE Router', wifiGen: '802.11ax (Wi-Fi 6)', dualBand: '2.4 GHz + 5 GHz', ports: '2x GbE', wan: 'Nano SIM 5G SA/NSA', thSpeed: '3800 Mbps Cellular', practicalSpeed: '350-750 Mbps 5G', mesh: 'Supported', price: 'Typical ₹18,000+', bestFor: 'High-Speed Wireless NOC' }
        ];

        const comparisonEntities = {
            jio_5g: { name: 'Jio True 5G (Mobile)', tech: '5G Standalone (SA)', dl: '420 Mbps (Est)', ul: '55 Mbps', latency: '19 ms', jitter: '3 ms', spectrum: 'n28 (700MHz), n78 (3.5GHz)', ipv6: 'Full Support', wifiGen: 'N/A (Cellular)', theoretical: '1 Gbps+', realworld: '300-500 Mbps', plan: 'Included in 5G Plans', best: 'Better for Mobile Coverage & Speed' },
            airtel_5g: { name: 'Airtel 5G Plus (Mobile)', tech: '5G Non-Standalone (NSA)', dl: '350 Mbps (Est)', ul: '42 Mbps', latency: '21 ms', jitter: '4 ms', spectrum: 'n78 (3.5GHz), 1800/2100MHz', ipv6: 'Full Support', wifiGen: 'N/A (Cellular)', theoretical: '1 Gbps+', realworld: '250-450 Mbps', plan: 'Included in 5G Plans', best: 'Better for Low Latency Gaming' },
            vi_4g: { name: 'Vi 4G / 5G Mobile', tech: '4G LTE-A / 5G Expanding', dl: '220 Mbps (Est)', ul: '28 Mbps', latency: '25 ms', jitter: '6 ms', spectrum: 'B1, B3, B8, B40, n78', ipv6: 'Supported', wifiGen: 'N/A (Cellular)', theoretical: '300 Mbps', realworld: '40-150 Mbps', plan: 'Standard Recharge', best: 'Better for Value Pricing' },
            bsnl_4g: { name: 'BSNL 4G Mobile', tech: '4G LTE', dl: '35 Mbps (Est)', ul: '12 Mbps', latency: '35 ms', jitter: '8 ms', spectrum: 'B1 (2100MHz), B8 (900MHz)', ipv6: 'Partial Support', wifiGen: 'N/A (Cellular)', theoretical: '100 Mbps', realworld: '15-35 Mbps', plan: 'Budget Tariffs', best: 'Better for Remote Coverage' },
            jio_fiber: { name: 'JioFiber 150 Mbps', tech: 'FTTH GPON Optical', dl: '150 Mbps (Symmetric)', ul: '150 Mbps', latency: '12 ms', jitter: '2 ms', spectrum: 'Optical Fiber Standard', ipv6: 'Dual Stack IPv4/IPv6', wifiGen: 'Wi-Fi 5 Bundled', theoretical: '150 Mbps', realworld: '138-148 Mbps', plan: '₹999/mo + GST', best: 'BETTER FOR FIBER & Value' },
            airtel_fiber: { name: 'Airtel Xstream 300 Mbps', tech: 'FTTH XPON Optical', dl: '300 Mbps (Symmetric)', ul: '300 Mbps', latency: '8 ms', jitter: '1.5 ms', spectrum: 'Optical Fiber Standard', ipv6: 'Dual Stack IPv4/IPv6', wifiGen: 'Wi-Fi 5 / 6 Router', theoretical: '300 Mbps', realworld: '280-295 Mbps', plan: '₹1,499/mo + GST', best: 'BETTER FOR LOW LATENCY' },
            tplink_ax3000: { name: 'TP-Link AX3000 Wi-Fi 6', tech: '802.11ax Standalone', dl: 'N/A (Local Router)', ul: 'N/A', latency: '1-2 ms (LAN)', jitter: '0.5 ms', spectrum: '2.4 GHz + 5 GHz Wi-Fi', ipv6: 'Supported', wifiGen: 'Wi-Fi 6 (802.11ax)', theoretical: '3000 Mbps', realworld: '600-900 Mbps LAN', plan: 'Hardware ₹4,999', best: 'BETTER FOR HIGH-DENSITY USERS' }
        };

        // Charts Initialization
        let chartThroughput, chartLatency;

        function initCharts() {
            const ctxTP = document.getElementById('chartThroughput').getContext('2d');
            chartThroughput = new Chart(ctxTP, {
                type: 'line',
                data: {
                    labels: ['-10s', '-8s', '-6s', '-4s', '-2s', 'Now'],
                    datasets: [
                        { label: 'Download (Mbps)', data: [132, 135, 138, 136, 139, 138.4], borderColor: '#3b82f6', backgroundColor: 'rgba(59, 130, 246, 0.1)', fill: true, tension: 0.3 },
                        { label: 'Upload (Mbps)', data: [85, 88, 90, 89, 91, 89.2], borderColor: '#06b6d4', borderDash: [4, 4], fill: false, tension: 0.3 }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { labels: { color: '#9ca3af', font: { family: 'JetBrains Mono', size: 10 } } } },
                    scales: {
                        x: { grid: { color: '#1f2937' }, ticks: { color: '#9ca3af', font: { family: 'JetBrains Mono', size: 9 } } },
                        y: { grid: { color: '#1f2937' }, ticks: { color: '#9ca3af', font: { family: 'JetBrains Mono', size: 9 } } }
                    }
                }
            });

            const ctxLat = document.getElementById('chartLatency').getContext('2d');
            chartLatency = new Chart(ctxLat, {
                type: 'line',
                data: {
                    labels: ['-10s', '-8s', '-6s', '-4s', '-2s', 'Now'],
                    datasets: [
                        { label: 'Latency (ms)', data: [19, 17, 18, 20, 18, 18], borderColor: '#22c55e', tension: 0.2 },
                        { label: 'Jitter (ms)', data: [3, 4, 4, 5, 4, 4], borderColor: '#f59e0b', tension: 0.2 }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { labels: { color: '#9ca3af', font: { family: 'JetBrains Mono', size: 10 } } } },
                    scales: {
                        x: { grid: { color: '#1f2937' }, ticks: { color: '#9ca3af', font: { family: 'JetBrains Mono', size: 9 } } },
                        y: { grid: { color: '#1f2937' }, ticks: { color: '#9ca3af', font: { family: 'JetBrains Mono', size: 9 } } }
                    }
                }
            });
        }

        // TAB SWITCHING LOGIC
        function switchTab(tabId) {
            state.currentTab = tabId;
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active', 'border-noc-accentBlue', 'text-noc-accentBlue');
                btn.classList.add('border-transparent', 'text-noc-textMuted');
            });

            const activeBtn = document.getElementById(`tab-${tabId}`);
            if (activeBtn) {
                activeBtn.classList.add('active', 'border-noc-accentBlue', 'text-noc-accentBlue');
                activeBtn.classList.remove('border-transparent', 'text-noc-textMuted');
            }

            document.querySelectorAll('main > section').forEach(sec => sec.classList.add('hidden'));
            const targetContent = document.getElementById(`content-${tabId}`);
            if (targetContent) targetContent.classList.remove('hidden');

            appendLog(`Switched active console tab to [${tabId.toUpperCase()}]`);
        }

        // SUB MODE SWITCH (Fiber vs Cellular)
        function setOverviewMode(mode) {
            state.overviewMode = mode;
            const btnFiber = document.getElementById('btn-mode-fiber');
            const btnCellular = document.getElementById('btn-mode-cellular');
            const viewFiber = document.getElementById('view-fiber');
            const viewCellular = document.getElementById('view-cellular');
            const tag = document.getElementById('topologyModeTag');

            if (mode === 'fiber') {
                btnFiber.className = 'flex-1 md:flex-none px-4 py-1.5 rounded-md font-semibold text-xs transition-all flex items-center justify-center gap-2 bg-noc-accentBlue text-white shadow';
                btnCellular.className = 'flex-1 md:flex-none px-4 py-1.5 rounded-md font-semibold text-xs transition-all flex items-center justify-center gap-2 text-noc-textMuted hover:text-white';
                viewFiber.classList.remove('hidden');
                viewCellular.classList.add('hidden');
                tag.innerText = 'Fiber FTTH';
                tag.className = 'text-noc-accentBlue uppercase font-bold';
            } else {
                btnCellular.className = 'flex-1 md:flex-none px-4 py-1.5 rounded-md font-semibold text-xs transition-all flex items-center justify-center gap-2 bg-noc-accentCyan text-white shadow';
                btnFiber.className = 'flex-1 md:flex-none px-4 py-1.5 rounded-md font-semibold text-xs transition-all flex items-center justify-center gap-2 text-noc-textMuted hover:text-white';
                viewCellular.classList.remove('hidden');
                viewFiber.classList.add('hidden');
                tag.innerText = 'Cellular 5G SA';
                tag.className = 'text-noc-accentCyan uppercase font-bold';
            }
            renderTopology();
            appendLog(`Switched Network Overview mode to [${mode.toUpperCase()}]`);
        }

        // RENDER WI-FI LIST
        function renderWifiList() {
            const container = document.getElementById('wifi-network-list');
            container.innerHTML = wifiNetworks.map((net, idx) => {
                const isSelected = idx === state.selectedWifiIndex;
                const statusColor = net.status === 'Excellent' ? 'text-emerald-400' : (net.status === 'Good' ? 'text-cyan-400' : 'text-amber-400');
                return `
                    <div onclick="selectWifiNetwork(${idx})" class="p-2.5 rounded-lg border cursor-pointer transition-all ${isSelected ? 'bg-noc-panelAlt border-noc-accentBlue shadow' : 'bg-noc-bg border-noc-border hover:border-gray-700'}">
                        <div class="flex items-center justify-between mb-1">
                            <span class="font-bold text-white flex items-center gap-1.5">
                                <i data-lucide="${net.band.includes('5') ? 'wifi' : 'wifi-off'}" class="w-3.5 h-3.5 ${isSelected ? 'text-noc-accentBlue' : 'text-gray-400'}"></i>
                                ${net.ssid}
                            </span>
                            <span class="text-[10px] px-1.5 py-0.5 rounded ${net.band.includes('5') ? 'bg-blue-500/10 text-noc-accentBlue border border-blue-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'}">${net.band}</span>
                        </div>
                        <div class="grid grid-cols-3 gap-1 text-[10px] text-noc-textMuted mt-1">
                            <span>Ch: <strong class="text-gray-200">${net.channel}</strong></span>
                            <span>RSSI: <strong class="${statusColor}">${net.rssi} dBm</strong></span>
                            <span>Sec: <strong class="text-gray-300">${net.security}</strong></span>
                        </div>
                    </div>
                `;
            }).join('');
            lucide.createIcons();
        }

        function selectWifiNetwork(idx) {
            state.selectedWifiIndex = idx;
            renderWifiList();
            const net = wifiNetworks[idx];
            document.getElementById('simBand').value = net.band.includes('5') ? '5' : '2.4';
            recalculateSimulation();
            appendLog(`Inspecting Wi-Fi SSID [${net.ssid}] (Channel ${net.channel}, RSSI: ${net.rssi} dBm)`);
        }

        // DYNAMIC MATHEMATICAL SIMULATION FORMULA
        function recalculateSimulation() {
            const plan = parseFloat(document.getElementById('simPlan').value);
            const routerType = document.getElementById('simRouter').value;
            const band = document.getElementById('simBand').value;
            const interference = document.getElementById('simInterference').value;
            const dist = parseFloat(document.getElementById('simDistance').value);
            const walls = parseInt(document.getElementById('simWalls').value);
            const devices = parseInt(document.getElementById('simDevices').value);

            // UI Label updates
            document.getElementById('lblDistance').innerText = `${dist} meters`;
            document.getElementById('lblWalls').innerText = `${walls} ${walls === 1 ? 'Wall' : 'Walls'}`;
            document.getElementById('lblDevices').innerText = `${devices} Devices`;
            document.getElementById('lblPlanSpeed').innerText = plan;

            // Mathematical calculation model
            let baseRSSI = band === '5' ? -42 : -45;
            let pathLoss = Math.log10(dist) * 18;
            let wallLoss = walls * 7.5;
            let interfLoss = interference === 'high' ? 8 : (interference === 'med' ? 4 : 0);
            
            let calculatedRSSI = Math.round(baseRSSI - pathLoss - wallLoss - interfLoss);
            if (calculatedRSSI < -95) calculatedRSSI = -95;

            // Throughput factor
            let signalQualityFactor = Math.max(0.2, (calculatedRSSI + 95) / 50);
            if (signalQualityFactor > 1) signalQualityFactor = 1;

            let routerFactor = routerType === 'tplink' || routerType === 'mesh' ? 0.96 : 0.88;
            let deviceCongestionFactor = Math.max(0.4, 1 - (devices * 0.015));
            let bandCap = band === '2.4' ? 120 : 1000;

            let estimatedDL = Math.min(plan, bandCap) * signalQualityFactor * routerFactor * deviceCongestionFactor;
            estimatedDL = Math.round(estimatedDL * 10) / 10;

            let basePing = 12;
            let distancePing = dist * 0.4;
            let wallPing = walls * 2.5;
            let loadPing = devices * 0.5;
            let totalPing = Math.round(basePing + distancePing + wallPing + loadPing);
            let jitter = Math.round((totalPing * 0.2) * 10) / 10;
            let packetLoss = calculatedRSSI < -80 ? 1.8 : (calculatedRSSI < -70 ? 0.6 : 0.1);

            let chanUtil = Math.min(98, Math.round(25 + (devices * 1.8) + (interference === 'high' ? 25 : 10)));

            // Health Status
            let health = 'EXCELLENT';
            let healthColor = 'text-noc-statusGreen';
            if (calculatedRSSI < -78 || estimatedDL < plan * 0.3) {
                health = 'POOR / DEGRADED';
                healthColor = 'text-noc-statusRed';
            } else if (calculatedRSSI < -68 || estimatedDL < plan * 0.6) {
                health = 'FAIR / MODERATE';
                healthColor = 'text-noc-statusAmber';
            }

            // Update DOM
            document.getElementById('gaugeDownload').innerHTML = `${estimatedDL} <span class="text-xs text-gray-400">Mbps</span>`;
            document.getElementById('gaugeRSSI').innerHTML = `${calculatedRSSI} <span class="text-xs text-gray-400">dBm</span>`;
            document.getElementById('gaugePing').innerHTML = `${totalPing} <span class="text-xs text-gray-400">ms</span>`;
            document.getElementById('gaugeLoss').innerHTML = `${packetLoss} <span class="text-xs text-gray-400">%</span>`;

            document.getElementById('lblJitter').innerText = jitter;
            document.getElementById('lblChanUtil').innerText = chanUtil;
            document.getElementById('connectionHealthLabel').innerText = `HEALTH: ${health}`;
            document.getElementById('connectionHealthLabel').className = `text-xs font-mono font-semibold ${healthColor}`;

            // Progress bar styles
            document.getElementById('barDownload').style.width = `${Math.min(100, (estimatedDL / plan) * 100)}%`;
            document.getElementById('barRSSI').style.width = `${Math.max(10, Math.min(100, 100 + calculatedRSSI))}%`;

            // Update Chart datasets
            if (chartThroughput && chartLatency) {
                chartThroughput.data.datasets[0].data.shift();
                chartThroughput.data.datasets[0].data.push(estimatedDL);
                chartThroughput.update('none');

                chartLatency.data.datasets[0].data.shift();
                chartLatency.data.datasets[0].data.push(totalPing);
                chartLatency.update('none');
            }

            state.calculatedMetrics = { download: estimatedDL, upload: Math.round(estimatedDL * 0.65), rssi: calculatedRSSI, ping: totalPing, jitter, loss: packetLoss, chanUtil, health };
        }

        // RENDER CELLULAR GRID BASED ON LOCATION PROFILE
        function updateLocationProfile() {
            const loc = document.getElementById('locationProfileSelect').value;
            state.location = loc;
            const profileName = document.getElementById('locationProfileSelect').options[document.getElementById('locationProfileSelect').selectedIndex].text;
            document.getElementById('cellularLocTitle').innerText = profileName;

            renderCellularGrid();
            appendLog(`Updated global location profile to [${profileName}]`);
        }

        function renderCellularGrid() {
            const grid = document.getElementById('cellularGrid');
            const data = locationCellProfiles[state.location] || locationCellProfiles.bengaluru;

            grid.innerHTML = data.map(cell => {
                const isJio = cell.operator === 'Jio';
                const isAirtel = cell.operator === 'Airtel';
                const accentClass = isJio ? 'text-noc-accentBlue' : (isAirtel ? 'text-red-400' : (cell.operator === 'Vi' ? 'text-yellow-400' : 'text-emerald-400'));
                const borderClass = isJio ? 'hover:border-blue-500/50' : (isAirtel ? 'hover:border-red-500/50' : 'hover:border-gray-600');

                return `
                    <div class="bg-noc-panelAlt p-4 rounded-xl border border-noc-border ${borderClass} transition-all space-y-3">
                        <div class="flex items-center justify-between border-b border-noc-border pb-2">
                            <div>
                                <h4 class="font-bold text-white text-sm flex items-center gap-1.5">
                                    <span class="${accentClass}">${cell.operator}</span>
                                    <span class="text-xs text-noc-textMuted font-mono">(${cell.tech})</span>
                                </h4>
                                <span class="text-[10px] text-gray-400 font-mono">${cell.site}</span>
                            </div>
                            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-noc-bg border border-noc-border ${accentClass}">${cell.band}</span>
                        </div>

                        <div class="grid grid-cols-2 gap-2 text-xs font-mono">
                            <div class="bg-noc-bg p-2 rounded border border-noc-border">
                                <span class="text-[10px] text-noc-textMuted block">Distance</span>
                                <span class="text-white font-bold">${cell.dist}</span>
                            </div>
                            <div class="bg-noc-bg p-2 rounded border border-noc-border">
                                <span class="text-[10px] text-noc-textMuted block">RSRP (Signal)</span>
                                <span class="${cell.rsrp > -90 ? 'text-emerald-400' : 'text-amber-400'} font-bold">${cell.rsrp} dBm</span>
                            </div>
                            <div class="bg-noc-bg p-2 rounded border border-noc-border">
                                <span class="text-[10px] text-noc-textMuted block">RSRQ</span>
                                <span class="text-gray-200 font-bold">${cell.rsrq} dB</span>
                            </div>
                            <div class="bg-noc-bg p-2 rounded border border-noc-border">
                                <span class="text-[10px] text-noc-textMuted block">SINR (Quality)</span>
                                <span class="text-cyan-400 font-bold">${cell.sinr} dB</span>
                            </div>
                        </div>

                        <div class="border-t border-noc-border pt-2 grid grid-cols-3 gap-1 text-center font-mono text-[11px]">
                            <div>
                                <span class="text-[9px] text-noc-textMuted block">Est. DL</span>
                                <span class="text-noc-accentBlue font-bold">${cell.dl} Mbps</span>
                            </div>
                            <div>
                                <span class="text-[9px] text-noc-textMuted block">Est. UL</span>
                                <span class="text-noc-accentCyan font-bold">${cell.ul} Mbps</span>
                            </div>
                            <div>
                                <span class="text-[9px] text-noc-textMuted block">Latency</span>
                                <span class="text-emerald-400 font-bold">${cell.ping} ms</span>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // RENDER INTERACTIVE TOPOLOGY DIAGRAM
        function renderTopology() {
            const container = document.getElementById('topologyNodesContainer');
            const isFiber = state.overviewMode === 'fiber';

            const nodes = isFiber ? [
                { id: 'n1', label: 'Internet Core', type: 'WAN Cloud', ip: '103.22.180.1', details: 'Tier-1 Backbone IX Transit • Peering: NIXI Mumbai' },
                { id: 'n2', label: 'ISP Core Switch', type: 'BRAS Server', ip: '10.240.0.1', details: 'Subscriber Session Termination • PPPoE/DHCP Dual-Stack' },
                { id: 'n3', label: 'OLT Node', type: 'Optical Line Terminal', ip: '172.16.4.12', details: 'GPON 2.5G/1.25G Optical Feeder Port #4' },
                { id: 'n4', label: 'Optical Splitter', type: 'Passive 1:32', ip: 'Passive Hardware', details: 'Passive Optical Attenuation: -18.5 dB loss' },
                { id: 'n5', label: 'Fiber ONT / CPE', type: 'Optical Network Terminal', ip: '192.168.1.1', details: 'Active RX Power: -21.4 dBm • Optical Lock: OK' },
                { id: 'n6', label: 'Wi-Fi 6 Router', type: 'Local Gateway', ip: '192.168.1.254', details: 'AX3000 Wi-Fi Band: 5GHz • Channel 149 (80MHz)' },
                { id: 'n7', label: 'Client Devices', type: 'End User Terminal', ip: '192.168.1.105', details: 'Connected: 8 Active Devices (Smartphones, Laptops)' }
            ] : [
                { id: 'c1', label: 'Internet Gateway', type: 'Core Network', ip: '49.207.0.1', details: '5GC UPF (User Plane Function) Routing Engine' },
                { id: 'c2', label: '5G Core Network', type: 'AMF / SMF Core', ip: '10.100.0.5', details: 'Control Plane Node • Standalone (SA) Architecture' },
                { id: 'c3', label: 'gNodeB Cell Site', type: 'Radio Base Station', ip: '172.28.9.44', details: 'n78 3500MHz Beamforming Active Antenna Unit' },
                { id: 'c4', label: 'Air Interface', type: 'RF Propagation', ip: 'NR-Uu Interface', details: '5G NR Sub-6GHz Airlink • RSRP: -82 dBm' },
                { id: 'c5', label: '5G CPE / Modem', type: 'Customer Terminal', ip: '192.168.0.1', details: 'Snapdragon X65 Modem Engine • 4x4 MIMO' },
                { id: 'c6', label: 'Ethernet / Wi-Fi', type: 'Local LAN', ip: '192.168.0.254', details: 'GbE Trunk Link to Local LAN Switches' },
                { id: 'c7', label: 'User Terminals', type: 'Client Nodes', ip: '192.168.0.12', details: 'High-Throughput Diagnostic Workstation' }
            ];

            container.innerHTML = nodes.map((n, i) => `
                <div class="flex items-center">
                    <div onclick="inspectNode('${n.label}', '${n.type}', '${n.ip}', '${n.details}')" class="bg-noc-panelAlt border border-noc-border hover:border-noc-accentBlue p-3 rounded-xl cursor-pointer transition-all text-center w-28 sm:w-32 shadow">
                        <i data-lucide="${i === 0 ? 'cloud' : (i === nodes.length - 1 ? 'laptop' : 'server')}" class="w-5 h-5 mx-auto mb-1 text-noc-accentBlue"></i>
                        <span class="text-xs font-bold text-white block truncate">${n.label}</span>
                        <span class="text-[9px] text-noc-textMuted font-mono block truncate">${n.type}</span>
                    </div>
                    ${i < nodes.length - 1 ? `
                        <div class="w-6 sm:w-10 h-0.5 bg-gradient-to-r from-noc-accentBlue to-noc-accentCyan mx-1 relative">
                            <i data-lucide="chevron-right" class="w-3 h-3 text-noc-accentCyan absolute -top-1 left-1/2 -translate-x-1/2"></i>
                        </div>
                    ` : ''}
                </div>
            `).join('');

            lucide.createIcons();
        }

        function inspectNode(label, type, ip, details) {
            document.getElementById('nodeModalTitle').innerHTML = `<i data-lucide="cpu" class="w-4 h-4 text-noc-accentBlue"></i> Node Inspector: ${label}`;
            document.getElementById('nodeModalContent').innerHTML = `
                <div class="p-2 bg-noc-bg rounded border border-noc-border">
                    <span class="text-noc-textMuted block text-[10px]">Node Category:</span>
                    <strong class="text-noc-accentCyan">${type}</strong>
                </div>
                <div class="p-2 bg-noc-bg rounded border border-noc-border">
                    <span class="text-noc-textMuted block text-[10px]">Interface IP / Address:</span>
                    <strong class="text-white font-mono">${ip}</strong>
                </div>
                <div class="p-2 bg-noc-bg rounded border border-noc-border">
                    <span class="text-noc-textMuted block text-[10px]">Telemetry & Link Status:</span>
                    <span class="text-gray-300 leading-relaxed block mt-1">${details}</span>
                </div>
            `;
            document.getElementById('nodeModal').classList.remove('hidden');
            lucide.createIcons();
        }

        function closeNodeModal() {
            document.getElementById('nodeModal').classList.add('hidden');
        }

        // RENDER ROUTERS & CPE MATRIX
        function renderRouterGrid(filter = 'all') {
            const grid = document.getElementById('routerGrid');
            const filtered = filter === 'all' ? routerDatabase : routerDatabase.filter(r => r.cat === filter);

            grid.innerHTML = filtered.map(r => `
                <div class="bg-noc-panel border border-noc-border hover:border-noc-borderBright rounded-xl p-4 shadow-sm flex flex-col justify-between space-y-3">
                    <div>
                        <div class="flex items-center justify-between border-b border-noc-border pb-2 mb-3">
                            <div>
                                <h3 class="font-bold text-white text-sm">${r.name}</h3>
                                <span class="text-[10px] text-noc-accentBlue font-mono">${r.categoryLabel}</span>
                            </div>
                            <span class="text-[10px] font-mono px-2 py-0.5 bg-noc-panelAlt border border-noc-border rounded text-gray-300">${r.wifiGen}</span>
                        </div>

                        <div class="space-y-1.5 text-xs font-mono text-noc-textMuted">
                            <div class="flex justify-between">
                                <span>Dual Band:</span>
                                <strong class="text-gray-200">${r.dualBand}</strong>
                            </div>
                            <div class="flex justify-between">
                                <span>Ports & WAN:</span>
                                <strong class="text-gray-200">${r.ports}</strong>
                            </div>
                            <div class="flex justify-between">
                                <span>Manufacturer Speed:</span>
                                <strong class="text-cyan-400">${r.thSpeed}</strong>
                            </div>
                            <div class="flex justify-between">
                                <span>Estimated Real Speed:</span>
                                <strong class="text-emerald-400">${r.practicalSpeed}</strong>
                            </div>
                            <div class="flex justify-between">
                                <span>Mesh Support:</span>
                                <strong class="text-gray-200">${r.mesh}</strong>
                            </div>
                        </div>
                    </div>

                    <div class="pt-2 border-t border-noc-border flex items-center justify-between text-xs font-mono">
                        <span class="text-amber-400 font-bold">${r.price}</span>
                        <span class="text-[10px] text-gray-400">${r.bestFor}</span>
                    </div>
                </div>
            `).join('');
        }

        function filterRouters(cat) {
            document.querySelectorAll('.router-filter-btn').forEach(btn => {
                btn.className = 'router-filter-btn px-3 py-1 bg-noc-panelAlt border border-noc-border text-gray-300 hover:text-white rounded';
            });
            event.target.className = 'router-filter-btn px-3 py-1 bg-noc-accentBlue text-white rounded';
            renderRouterGrid(cat);
        }

        // RENDER COMPARISON ENGINE
        function renderComparison() {
            const keyA = document.getElementById('compareA').value;
            const keyB = document.getElementById('compareB').value;

            const itemA = comparisonEntities[keyA];
            const itemB = comparisonEntities[keyB];

            document.getElementById('thEntityA').innerText = itemA.name;
            document.getElementById('thEntityB').innerText = itemB.name;

            const metrics = [
                { label: 'Technology / Architecture', key: 'tech' },
                { label: 'Estimated Downlink Speed', key: 'dl' },
                { label: 'Estimated Uplink Speed', key: 'ul' },
                { label: 'Latency / Ping', key: 'latency' },
                { label: 'Jitter Telemetry', key: 'jitter' },
                { label: 'Radio Frequency / Spectrum', key: 'spectrum' },
                { label: 'IPv6 Support', key: 'ipv6' },
                { label: 'Wi-Fi Generation', key: 'wifiGen' },
                { label: 'Theoretical Max Speed', key: 'theoretical' },
                { label: 'Estimated Real-World Speed', key: 'realworld' },
                { label: 'Pricing / Plan Tier', key: 'plan' },
                { label: 'Primary Recommendation', key: 'best' }
            ];

            const tbody = document.getElementById('comparisonTableBody');
            tbody.innerHTML = metrics.map(m => `
                <tr class="hover:bg-noc-panelAlt/50">
                    <td class="p-3 text-noc-textMuted font-semibold">${m.label}</td>
                    <td class="p-3 text-white font-mono">${itemA[m.key]}</td>
                    <td class="p-3 text-noc-accentCyan font-mono">${itemB[m.key]}</td>
                </tr>
            `).join('');

            // Verdict Badges Calculation
            const badgesContainer = document.getElementById('verdictBadges');
            let badgesHTML = '';

            if (itemA.best) {
                badgesHTML += `<span class="px-3 py-1 bg-blue-500/10 text-noc-accentBlue border border-blue-500/30 rounded-full text-xs font-mono font-bold">${itemA.name}: ${itemA.best}</span>`;
            }
            if (itemB.best) {
                badgesHTML += `<span class="px-3 py-1 bg-cyan-500/10 text-noc-accentCyan border border-cyan-500/30 rounded-full text-xs font-mono font-bold">${itemB.name}: ${itemB.best}</span>`;
            }

            badgesContainer.innerHTML = badgesHTML;
        }

        // TERMINAL LOG ENGINE
        function appendLog(msg) {
            const term = document.getElementById('terminalLog');
            if (!term) return;
            const now = new Date();
            const timeStr = now.toTimeString().split(' ')[0] + '.' + Math.floor(now.getMilliseconds()/100);
            const line = document.createElement('div');
            line.innerHTML = `<span class="text-noc-textMuted">[${timeStr}]</span> <span class="text-gray-300">${msg}</span>`;
            term.appendChild(line);
            term.scrollTop = term.scrollHeight;
        }

        function startAutoLogger() {
            const logs = [
                "Evaluating RSRP signal propagation delta across gNodeB sector 2",
                "Periodic ping telemetry echo received: 18ms latency, 0.2% loss",
                "Wi-Fi channel 149 clear: noise floor measured at -92 dBm",
                "Jio True 5G SA core session authentication handshake successful",
                "Airtel 5G Plus NSA carrier aggregation active (n78 + 1800 MHz)",
                "Updating simulated link capacity for selected location profile"
            ];
            let idx = 0;
            setInterval(() => {
                appendLog(logs[idx % logs.length]);
                idx++;
            }, 6000);
        }

        // REPORT MODAL ENGINE
        function openReportModal() {
            const m = state.calculatedMetrics;
            const now = new Date().toLocaleString();
            const body = document.getElementById('reportModalBody');

            body.innerHTML = `
                <div class="p-3 bg-noc-bg border border-noc-border rounded-lg">
                    <div class="flex justify-between text-gray-400 text-[10px] border-b border-noc-border pb-1 mb-2">
                        <span>REPORT ID: NOC-SIM-2026-${Math.floor(1000 + Math.random() * 9000)}</span>
                        <span>DATE: ${now}</span>
                    </div>
                    <strong class="text-noc-accentBlue text-sm block font-sans font-bold">EXECUTIVE DIAGNOSTIC SUMMARY</strong>
                    <p class="text-noc-textMuted mt-1">Location Profile: <strong class="text-white">${state.location.toUpperCase()}</strong> | Active Mode: <strong class="text-white">${state.overviewMode.toUpperCase()}</strong></p>
                </div>

                <div class="grid grid-cols-2 gap-2 text-xs">
                    <div class="bg-noc-panelAlt p-2.5 rounded border border-noc-border">
                        <span class="text-noc-textMuted block">Est. Throughput:</span>
                        <strong class="text-noc-accentBlue font-mono text-sm">${m.download} Mbps DL / ${m.upload} Mbps UL</strong>
                    </div>
                    <div class="bg-noc-panelAlt p-2.5 rounded border border-noc-border">
                        <span class="text-noc-textMuted block">Ping / Jitter:</span>
                        <strong class="text-emerald-400 font-mono text-sm">${m.ping} ms / ${m.jitter} ms</strong>
                    </div>
                    <div class="bg-noc-panelAlt p-2.5 rounded border border-noc-border">
                        <span class="text-noc-textMuted block">Wi-Fi RSSI Signal:</span>
                        <strong class="text-cyan-400 font-mono text-sm">${m.rssi} dBm</strong>
                    </div>
                    <div class="bg-noc-panelAlt p-2.5 rounded border border-noc-border">
                        <span class="text-noc-textMuted block">Link Health Rating:</span>
                        <strong class="text-emerald-400 font-mono text-sm">${m.health}</strong>
                    </div>
                </div>

                <div class="p-3 bg-noc-panelAlt rounded border border-noc-border space-y-2">
                    <strong class="text-gray-200 block text-xs">Potential Bottlenecks & Recommendations:</strong>
                    <ul class="list-disc pl-4 text-noc-textMuted space-y-1 text-[11px]">
                        <li>5 GHz spectrum attenuation is moderate through 1 concrete obstacle wall.</li>
                        <li>Channel utilization is optimal (${m.chanUtil}% load). No immediate spectrum migration needed.</li>
                        <li>Consider enabling Wi-Fi 6 (802.11ax) OFDMA for enhanced multi-device throughput distribution.</li>
                    </ul>
                </div>

                <div class="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[10px] rounded leading-relaxed">
                    <strong>DISCLAIMER:</strong> This report contains simulated/estimated network values for demonstration and research purposes. It is not a substitute for operator network telemetry, RF field measurements, or an official coverage map.
                </div>
            `;

            document.getElementById('reportModal').classList.remove('hidden');
            appendLog('Generated and opened diagnostic summary audit report.');
        }

        function closeReportModal() {
            document.getElementById('reportModal').classList.add('hidden');
        }

        function downloadCSVReport() {
            const m = state.calculatedMetrics;
            const csvContent = "data:text/csv;charset=utf-8," 
                + "Parameter,Value,Unit\n"
                + `Estimated Download,${m.download},Mbps\n`
                + `Estimated Upload,${m.upload},Mbps\n`
                + `Ping Latency,${m.ping},ms\n`
                + `Signal RSSI,${m.rssi},dBm\n`
                + `Packet Loss,${m.loss},%\n`
                + `Channel Utilization,${m.chanUtil},%\n`
                + `Health Status,${m.health},Rating\n`;
            
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `Network_Diagnostic_Report_${Date.now()}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            appendLog("Exported diagnostic report to CSV file.");
        }

        function exportJSONData() {
            const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state, null, 2));
            const dlAnchor = document.createElement('a');
            dlAnchor.setAttribute("href", dataStr);
            dlAnchor.setAttribute("download", `NOC_Telemetry_Export_${Date.now()}.json`);
            document.body.appendChild(dlAnchor);
            dlAnchor.click();
            dlAnchor.remove();
            appendLog("Exported console state telemetry to JSON.");
        }

        function runGlobalDiagnostic() {
            appendLog("Executing full system diagnostic sequence...");
            let count = 0;
            const interval = setInterval(() => {
                count++;
                recalculateSimulation();
                if (count >= 3) {
                    clearInterval(interval);
                    appendLog("Full Diagnostic sweep finished. Metrics stabilized.");
                }
            }, 300);
        }

        function resetAllSimulations() {
            state.selectedWifiIndex = 0;
            document.getElementById('simPlan').value = "150";
            document.getElementById('simRouter').value = "jio";
            document.getElementById('simBand').value = "5";
            document.getElementById('simInterference').value = "med";
            document.getElementById('simDistance').value = 4.5;
            document.getElementById('simWalls').value = 1;
            document.getElementById('simDevices').value = 8;
            recalculateSimulation();
            appendLog("Reset all diagnostic simulation parameters to default baseline.");
        }

        // INITIALIZATION ON PAGE LOAD
        window.addEventListener('DOMContentLoaded', () => {
            initCharts();
            renderWifiList();
            recalculateSimulation();
            renderCellularGrid();
            renderTopology();
            renderRouterGrid();
            renderComparison();
            appendLog("Simulation console initialized. Data profiles ready.");
            startAutoLogger();
        });